//
//  PersonalRecords.swift
//  Remedex
//
//  Created by Shreya Bhavsar on 20/01/24.
//

import Foundation

class PersonalRecords: ObservableObject, Identifiable {
    var id = UUID()
    @Published var firstName: String = ""
    @Published var lastName: String = ""
    @Published var email: String = ""
    @Published var phoneNumber: String = ""
    @Published var birthDate: Date = Date()
    @Published var age: Int = 0
    @Published var height: String = ""
    @Published var weight: String = ""
    @Published var bmi: String = ""
    @Published var gender: String = ""
    @Published var selectedSymptoms: Set<String> = []
    @Published var selectedTypes: Set<String> = []
    @Published var selectedAnswer: Set<String> = []
    @Published var selectedFeelings: String = ""
}

