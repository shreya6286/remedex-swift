//
//  DataManagerIllness.swift
//  Remedex
//
//  Created by Shreya Bhavsar on 20/01/24.
//

import Foundation

class DataManagerIllness: ObservableObject, Identifiable {
    static let shared = DataManagerIllness()
    @Published var illnesses: [Illness] = []
    
    init() {
           self.illnesses = [
            Illness.create(
                name: "Headaches",
                desc: "A painful sensation in any part of the head, ranging from sharp to dull, that may occur with other symptoms.",
                symptoms: ["Headache", "Tension", "Pressure",  "Throbbing Pain","Aching Sensation","Light Sensitivity",
                    "Sound Sensitivity","Nausea","Vomiting","Irritability",
                    "Fatigue","Difficulty Concentrating"],
                types: ["Tension", "Cluster","Migraine","Sinus","Withdrawal","Exertion","Rebound","Chronic"],
                preSick: false,
                bodyParts: ["Head"],
                feelings: [""],
                treatments: [""],
                prevention: [""],
                img: "",
                relatedHomemadeRecords: [
                    HomemadeCategories(
                        title: "Eucalyptus Steam Inhale ",
                        menu: .eucalyptus,
                        desc: "Inhaling steam with a few drops of eucalyptus oil can help open nasal passages and relieve tension, providing relief from headaches.",
                        img: "eucalyptus"
                    ),
                    HomemadeCategories(
                        title: "Lavender Lemonade",
                        menu: .lavenderLemonade,
                        desc: "A refreshing drink infused with lavender and lemon. Lavender helps in reducing headache symptoms and lemon provides hydration.",
                        img: "lavenderLemonade"
                    ),
                    HomemadeCategories(
                        title: "Rosemary Infused Water",
                        menu: .rosemary,
                        desc: "Infusing water with rosemary, a herb with potential headache-relieving properties, can be a hydrating and soothing remedy.",
                        img: "rosemary"
                    ),
                    HomemadeCategories(
                        title: "Peppermint Headache Oil",
                        menu: .peppermint,
                        desc: "A soothing balm made with peppermint oil, coconut oil and bees wax. Peppermint oil is known for its ability to rekax muscles and ease headaches",
                        img: "peppermint"
                    )
                ],
                relatedPharmacyRecords: [
                PharmacyCategories(
                    title: "Tylenol (Paracetamol)",
                    menu: .tylenol,
                    desc: "Tylenol is a pain reliever and fever reducer. It can help alleviate headaches and reduce fever associated with colds.",
                    img: "tylenol"
                ),
                PharmacyCategories(
                    title: "Advil (Ibuprofen)",
                    menu: .advil,
                    desc: "Advil is a nonsteroidal anti-inflammatory drug (NSAID) that can help reduce inflammation, fever, and relieve pain.",
                    img: "advil"
                ),
                PharmacyCategories(
                    title: "Excedrin (Aspirin)",
                    menu: .excedrin,
                    desc: "Excedrin is a combination medication containing acetaminophen, aspirin, and caffeine, specifically formulated to provide relief from headaches.",
                    img: "excedrin"
                ),
                PharmacyCategories(
                    title: "Aleve (Naprosyn)",
                    menu: .aleve,
                    desc: "Aleve is a nonsteroidal anti-inflammatory drug (NSAID) that can help relieve pain and reduce inflammation, including headaches.",
                    img: "aleve"
                )
            ], relatedFitnessRecords: [
                FitnessCategories(
                    title: "Yoga",
                    menu: .yoga,
                    desc: "",
                    img: ""
                )
            ],
                relatedYogaRecords: [
                    MainCategories(
                        title: "Cat-Cow Stretch",
                        menu: .catCow,
                        desc: "A flowing sequence of yoga poses that involves arching and rounding the spine, promoting flexibility and relieving tension in the neck and upper back, potentially alleviating headaches.",
                        img: "catCow"
                    ),
                    MainCategories(
                        title: "Extended Triangle Pose",
                        menu: .trianglePose,
                        desc: "A standing pose that involves reaching one hand to the floor while extending the other arm upward, promoting a stretch in the neck and shoulders and potential headache relief.",
                        img: "trianglePose"
                    ),
                    MainCategories(
                        title: "Corpse Pose (Savasana)",
                        menu: .corpsePose,
                        desc: "A relaxation pose where you lie on your back, allowing your body to rest and release tension, promoting overall relaxation and potential relief from headaches.",
                        img: "corpsePose"
                    ),
                    MainCategories(
                        title: "Deep Breathing",
                        menu: .pranayama,
                        desc: "A series of controlled breathing exercises that help relax the nervous system, reduce stress, and potentially alleviate headaches.",
                        img: "pranayama"
                    )
                ],relatedExerciseRecords: [
                    MainCategories(
                         title: "Side Neck Stretches",
                         menu: .neck,
                         desc: "Gently stretch and release tension in your neck muscles to relieve migraine discomfort.",
                         img: "neck"
                     ),
                    MainCategories(
                        title: "Pilates Sessions",
                        menu: .pilates,
                        desc: "Participating in Pilates sessions to strengthen core muscles, improve posture, and reduce tension in the body, potentially alleviating headaches.",
                        img: "pilates"
                       ),
                    MainCategories(
                            title: "Face Acupressure",
                            menu: .pressure,
                            desc: "Apply pressure to specific points on the body, such as the temples or between the eyebrows, to alleviate migraine pain.",
                            img: "pressure"
                        ),
                    MainCategories(
                        title: "Shoulder Roll Exercises",
                        menu: .shoulderRolls,
                        desc: "Roll your shoulders in a circular motion to release tension in the shoulder muscles and improve blood flow to the head.",
                        img: "shoulderRolls"
                    )
                ]
        ),

            Illness.create(
                name: "Concussion",
                desc: "A brain injury caused by a blow to the head, often resulting in temporary loss of normal brain function.",
                symptoms: ["Headache", "Dizziness", "Memory loss","Nausea or vomiting","Confusion","Blurred or double vision","Sensitivity to light","Difficulty concentrating","Fatigue","Sleep disturbances"],
                types: ["Mild","Moderate", "Severe"],
                preSick: true,
                bodyParts: [""],
                feelings: [""],
                treatments: [""],
                prevention: [""],
                img: "",
                relatedHomemadeRecords: [
                    HomemadeCategories(
                        title: "Salmon Salad with Omega-3",
                        menu: .salmon,
                        desc: "A nutrient-rich salad featuring salmon, rich in omega-3 fatty acids, which may contribute to brain health and recovery.",
                        img: "salmon"
                    ),
                    HomemadeCategories(
                        title: "Blueberry Smoothie",
                        menu: .blueberry,
                        desc: "A smoothie made with blueberries, known for their antioxidant properties that may support overall brain function.",
                        img: "blueberry"
                    ),
                    HomemadeCategories(
                        title: "Spinach and Quinoa Bowl",
                        menu: .spinach,
                        desc: "A quinoa bowl incorporating spinach and walnuts, providing a mix of nutrients like iron and omega-3 fatty acids that may support brain health.",
                        img: "spinach"
                    ),
                    HomemadeCategories(
                        title: "Turmeric Golden Milk",
                        menu: .goldenMilk,
                        desc: "A warm beverage made with turmeric, known for its anti-inflammatory properties that may aid in the recovery process.",
                        img: "goldenMilk"
                    )
                ],
                relatedPharmacyRecords: [
                PharmacyCategories(
                    title: "Aleve (Naproxen)",
                    menu: .aleve,
                    desc: "Naproxen is another NSAID that helps reduce pain, inflammation, and fever. It can be used to manage headache and pain associated with concussion.",
                    img: "aleve"
                ),
                PharmacyCategories(
                    title: "Advil (Ibuprofen)",
                    menu: .advil,
                    desc: "Advil is a nonsteroidal anti-inflammatory drug (NSAID) that can help reduce inflammation and relieve pain. It may be useful for managing pain related to concussions.",
                    img: "advil"
                ),
                PharmacyCategories(
                    title: "Zofran (Ondanstron)",
                    menu: .zofran,
                    desc: "Zofran is an anti-nausea medication that can be helpful in managing nausea and vomiting, which are common symptoms associated with concussions.",
                    img: "zofran"
                ),
                PharmacyCategories(
                    title: "Amitriptyline Tablets",
                    menu: .amitriptyline,
                    desc: "Amitriptyline is a tricyclic antidepressant that may be prescribed for managing persistent headaches or migraines following a concussion.",
                    img: "amitriptyline"
                )
            ], relatedFitnessRecords: [
                FitnessCategories(
                    title: "Yoga",
                    menu: .yoga,
                    desc: "",
                    img: ""
                )
            ],
                relatedYogaRecords: [
                    MainCategories(
                        title: "Child's Pose with Support",
                        menu: .childsPoseHead,
                        desc: "A restorative yoga pose where you sit back on your heels, extending your arms forward and resting your forehead on the mat. This gentle stretch helps promote relaxation and reduces tension in the head and neck.",
                        img: "childsPoseHead"
                    ),

                    MainCategories(
                        title: "Seated Neck Stretches",
                        menu: .neckStretches,
                        desc: "Sit comfortably and slowly tilt your head from side to side, gently stretching the neck muscles. This helps release tension and improve flexibility in the neck area, promoting recovery from a concussion.",
                        img: "neckStretches"
                    ),
                    MainCategories(
                        title: "Gentle Seated Twists",
                        menu: .seatedTwists,
                        desc: "Sit comfortably and gently twist your upper body from side to side. This helps release tension in the spine and neck, providing relief during the recovery from a concussion.",
                        img: "seatedTwists"
                    ),

                    MainCategories(
                        title: "Supported Forward Fold",
                        menu: .forwardFold,
                        desc: "Sit with legs extended and fold forward, resting your head on a support. This pose promotes relaxation and releases tension in the neck and shoulders, aiding in concussion recovery.",
                        img: "forwardFold"
                    )
                ],relatedExerciseRecords: [
                    MainCategories(
                        title: "Bodyweight Squats",
                        menu: .bodSquats,
                        desc: "Performing bodyweight squats helps strengthen the lower body muscles without putting too much strain on the head and neck.",
                        img: "bodSquats"
                    ),
                    MainCategories(
                        title: "Modified Push-Ups",
                        menu: .modPushUps,
                        desc: "Doing push-ups against a wall or on an elevated surface reduces the strain on the head and neck while still engaging upper body muscles.",
                        img: "modPushUps"
                    ),
                    MainCategories(
                        title: "Plank Variations",
                        menu: .plankVar,
                        desc: "Engage in plank variations such as forearm plank or side plank to strengthen core muscles and improve stability without excessive head movement.",
                        img: "plankVar"
                    ),
                    MainCategories(
                        title: "Bodyweight Lunges",
                        menu: .bodLunges,
                        desc: "Performing bodyweight lunges helps strengthen the legs and improve balance without the need for equipment, minimizing the risk of exacerbating concussion symptoms.",
                        img: "bodLunges"
                    )
                ]
        ),

            Illness.create(
                name: "Nose Bleed",
                desc: "Bleeding from the nose, either spontaneous or induced by nose picking or trauma.",
                symptoms: ["Bleeding from the nostrils", "Dizziness", "NasalEase","ClotStop"],
                types: ["Anterior", "Posterior", "Traumatic","Spontaneous","Dry Air","Drug-Related"],
                preSick: false,
                bodyParts: ["Head"],
                feelings: [""],
                treatments: [""],
                prevention: [""],
                img: "",
                relatedHomemadeRecords: [
                    HomemadeCategories(
                        title: "Saline Nasal Rinse",
                        menu: .netiPot,
                        desc: "A gentle saline solution used for nasal irrigation, which helps keep the nasal passages moist and prevent nosebleeds.",
                        img: "netiPot"
                    ),
                    HomemadeCategories(
                        title: "Vitamin C-rich Foods",
                        menu: .vitaminC,
                        desc: "Incorporating foods rich in vitamin C, such as citrus fruits and berries, to support blood vessel health and reduce the risk of nosebleeds.",
                        img: "vitaminC"
                    ),
                    HomemadeCategories(
                        title: "Eucalyptus Steam Inhale",
                        menu: .eucalyptus,
                        desc: "Inhaling steam infused with eucalyptus oil to moisturize the nasal passages and promote healing, reducing the likelihood of nosebleeds.",
                        img: "eucalyptus"
                    ),
                    HomemadeCategories(
                        title: "Aloe Vera Gel Application",
                        menu: .aloeVera,
                        desc: "Applying a small amount of pure aloe vera gel inside the nostrils to soothe and moisturize the nasal lining, helping prevent nosebleeds.",
                        img: "aloeVera"
                    )
                ],
                relatedPharmacyRecords: [
                PharmacyCategories(
                    title: "Afrin Nasal Spray",
                    menu: .afrin,
                    desc: "Afrin is a nasal spray that constricts blood vessels in the nasal passages, helping to reduce bleeding during a nosebleed.",
                    img: "afrin"
                ),
                PharmacyCategories(
                    title: "NasalCrom (Intal)",
                    menu: .nascrom,
                    desc: "NasalCrom is a nasal spray that helps prevent and relieve nasal allergy symptoms, which may contribute to nosebleeds.",
                    img: "nascrom"
                ),
                PharmacyCategories(
                    title: "Saline Nasal Spray",
                    menu: .saline,
                    desc: "Saline nasal spray provides gentle moisture to the nasal passages, promoting healing and preventing dryness that can lead to nosebleeds.",
                    img: "saline"
                ),
                PharmacyCategories(
                    title: "Vaseline Nasal Ointment",
                    menu: .vaseline,
                    desc: "Applying a small amount of Vaseline inside the nostrils can help moisturize and soothe dry nasal passages, reducing the risk of nosebleeds.",
                    img: "vaseline"
                )
            ], relatedFitnessRecords: [
                FitnessCategories(
                    title: "Yoga",
                    menu: .yoga,
                    desc: "",
                    img: ""
                )
            ],
                relatedYogaRecords: [
                    MainCategories(
                        title: "Sitali Pranayama",
                        menu: .sitaliPranayama,
                        desc: "A cooling breathing technique where you inhale through a rolled tongue or pursed lips, helping to cool the body and potentially alleviate conditions that may contribute to nosebleeds.",
                        img: "sitaliPranayama"
                    ),

                    MainCategories(
                        title: "Legs Up the Wall Pose",
                        menu: .legsUpWall,
                        desc: "By resting with your legs elevated against a wall, this pose may help improve blood circulation, reduce stress, and promote overall well-being, potentially preventing nosebleeds.",
                        img: "legsUpWall"
                    ),

                    MainCategories(
                        title: "Sheetkari Pranayama",
                        menu: .sheetkariPranayama,
                        desc: "A breathing exercise where you inhale through clenched teeth, followed by a slow exhale through the nose, believed to have a calming effect on the nervous system and potentially reducing nosebleed triggers.",
                        img: "sheetkariPranayama"
                    ),
                    MainCategories(
                        title: "Kapalbhati Pranayama",
                        menu: .kapalbhatiPranayama,
                        desc: "A dynamic breathing technique involving rapid exhales and passive inhales, believed to cleanse the respiratory system and improve lung capacity, potentially reducing the likelihood of nosebleeds.",
                        img: "kapalbhatiPranayama"
                    ),
                ],relatedExerciseRecords: [
                    MainCategories(
                        title: "Seated Leg Lifts",
                        menu: .seatedLegLifts,
                        desc: "Perform seated leg lifts to engage your leg muscles without putting strain on your upper body, which can help minimize the risk of exacerbating a nosebleed.",
                        img: "seatedLegLifts"
                    ),
                    MainCategories(
                        title: "Wall Push-Ups",
                        menu: .wallPushUps,
                        desc: "Perform push-ups against a wall to engage your chest, shoulder, and arm muscles while maintaining an upright position to avoid worsening a nosebleed.",
                        img: "wallPushUps"
                    ),
                    MainCategories(
                        title: "Chair Dips Exercise",
                        menu: .chairDips,
                        desc: "Engage in chair dips to strengthen your triceps and shoulders while seated, reducing the risk of strain or sudden movements that could trigger or worsen a nosebleed.",
                        img: "chairDips"
                    ),
                    MainCategories(
                        title: "Standing Leg Raises",
                        menu: .standLegRaise,
                        desc: "Perform standing leg raises to strengthen your hip flexors and thighs while maintaining a stable posture, minimizing the risk of exacerbating a nosebleed.",
                        img: "standLegRaise"
                    )
                ]
            ),

            Illness.create(
                name: "Common Cold",
                desc: "Viral infection causing symptoms like sneezing, runny nose, and cough.",
                symptoms: ["Runny nose", "Sneezing", "Cough", "Nasal Congestion","Sore Throat","Headache","Fatigue","Body Aches","Fever"],
                types: ["Rhinovirus", "Coronavirus", "Adenovirus","Influenza","Parainfluenza"],
                preSick: false,
                bodyParts: ["Head"],
                feelings: [""],
                treatments: [""],
                prevention: [""],
                img: "",
                relatedHomemadeRecords: [
                    HomemadeCategories(
                        title: "Spicy Chicken Soup",
                        menu: .spicyChickenSoup,
                        desc: "A classic comfort food, chicken soup can help soothe a sore throat and provide hydration, while the warmth may ease nasal congestion.",
                        img: "spicyChickenSoup"
                    ),
                    HomemadeCategories(
                        title: "Honey Lemon Ginger Tea",
                        menu: .gingerLemonade,
                        desc: "A soothing tea made with honey, lemon, and ginger, known for its antioxidant and anti-inflammatory properties, helping relieve cold symptoms.",
                        img: "gingerLemonade"
                    ),
                    HomemadeCategories(
                        title: "Garlic and Honey Drink",
                        menu: .garlicHoney,
                        desc: "An infusion made by combining crushed garlic and honey, believed to have antibacterial properties and help alleviate cold symptoms.",
                        img: "garlicHoney"
                    ),
                    HomemadeCategories(
                        title: "Broth with Chili Peppers",
                        menu: .spicyBroth,
                        desc: "A broth infused with chili peppers, which may help open nasal passages and provide relief from congestion during a common cold.",
                        img: "spicyBroth"
                    )
                ],
                relatedPharmacyRecords: [
                PharmacyCategories(
                    title: "Tylenol Cold + Flu",
                    menu: .tylenolColdFlu,
                    desc: "Tylenol Cold + Flu is a combination medication that provides relief from pain, fever, cough, and congestion associated with the common cold.",
                    img: "tylenolColdFlu"
                ),
                PharmacyCategories(
                    title: "DayQuil/NyQuil (Vicks)",
                    menu: .dayNyQuil,
                    desc: "DayQuil and NyQuil are over-the-counter medications that provide daytime and nighttime relief from multiple cold symptoms, including cough, congestion, and fever.",
                    img: "dayNyQuil"
                ),
                PharmacyCategories(
                    title: "Chloraseptic Throat Spray",
                    menu: .chloraseptic,
                    desc: "Chloraseptic Sore Throat Spray contains a numbing agent to provide quick relief from sore throat pain and irritation caused by the common cold.",
                    img: "chloraseptic"
                ),
                PharmacyCategories(
                    title: "Ricola Herbal Cough Drops",
                    menu: .ricola,
                    desc: "Ricola Herbal Cough Drops contain a blend of natural herbs to soothe the throat and relieve cough associated with the common cold.",
                    img: "ricola"
                )
            ], relatedFitnessRecords: [
                FitnessCategories(
                    title: "Yoga",
                    menu: .yoga,
                    desc: "",
                    img: ""
                )
            ],
                relatedYogaRecords: [
                    MainCategories(
                            title: "Alternate Nostril Breath",
                            menu: .nostrilBreathing,
                            desc: "A yogic breathing technique involving the alternate inhalation and exhalation through each nostril, aiming to clear and balance the nasal passages in colds.",
                            img: "nostrilBreathing"
                        ),
                        MainCategories(
                            title: "Wind-Relieving Pose",
                            menu: .windRelievingPose,
                            desc: "A pose where you lie on your back and hug your knees into your chest, aiding digestion and relieving discomfort from cold symptoms.",
                            img: "windRelievingPose"
                        ),
                        MainCategories(
                            title: "Neti Pot Technique",
                            menu: .netiPot,
                            desc: "Although not a traditional yoga pose, the Neti Pot technique involves using a saline solution to flush out nasal passages, helping to relieve congestion and cold symptoms.",
                            img: "neti"
                        ),
                    MainCategories(
                        title: "Kapalbhati Pranayama",
                        menu: .kapalbhatiPranayama,
                        desc: "A dynamic breathing technique involving rapid exhales and passive inhales, believed to cleanse the respiratory system and improve lung capacity, potentially reducing the likelihood of nosebleeds.",
                        img: "kapalbhatiPranayama"
                    ),
                ],relatedExerciseRecords: [
                    MainCategories(
                        title: "Bodyweight Squats",
                        menu: .bodSquats,
                        desc: "Perform bodyweight squats to promote blood circulation and maintain lower body strength while recovering from a cold.",
                        img: "bodSquats"
                    ),
                    MainCategories(
                        title: "Push-Ups Exercise",
                        menu: .pushUps,
                        desc: "Engage in push-ups to strengthen the upper body and maintain overall muscle tone during a cold.",
                        img: "pushUps"
                    ),
                    MainCategories(
                        title: "Jumping Jacks",
                        menu: .jumpJacks,
                        desc: "Do jumping jacks to elevate the heart rate, improve circulation, and boost energy levels while fighting off a cold.",
                        img: "jumpJacks"
                    ),
                    MainCategories(
                        title: "Plank Exercises",
                        menu: .plank,
                        desc: "Hold a plank position to strengthen the core muscles and maintain stability and balance even when feeling under the weather.",
                        img: "plank"
                    )
                ]
        ),

            Illness.create(
                name: "Cough",
                desc: "Reflex action to clear the throat or airways of irritants.",
                symptoms: ["Persistent cough", "Throat irritation", "Hoarseness", "Shortness of Breath","Chest Pain", "Wheezing","Nasal Congestion", "Fever","Fatigue","Body Aches","Headache"],
                types: ["Acute", "Chronic", "Dry", "Wet", "Persistent", "Itchy", "Smoker's", "Allergic"],
                preSick: false,
                bodyParts: ["Chest","Head"],
                feelings: [""],
                treatments: [""],
                prevention: [""],
                img: "",
                relatedHomemadeRecords: [
                    HomemadeCategories(
                        title: "Eucalyptus Steam Inhale",
                        menu: .eucalyptus,
                        desc: "Eucalyptus oil has decongestant properties and can help clear nasal passages, making it easier to breathe and relieving cough symptoms.",
                        img: "eucalyptus"
                    ),
                    HomemadeCategories(
                        title: "Spicy Chicken Soup",
                        menu: .spicyChickenSoup,
                        desc: "Homemade chicken soup with nourishing broth, vegetables, and herbs, providing warmth and comfort for individuals with a cough.",
                        img: "spicyChickenSoup"
                    ),
                    HomemadeCategories(
                        title: "Turmeric Milk (Golden Milk)",
                        menu: .goldenMilk,
                        desc: "A warm milk drink infused with turmeric, honey, and spices, celebrated for its anti-inflammatory and immune-boosting benefits.",
                        img: "goldenMilk"
                    ),
                    HomemadeCategories(
                        title: "Chamomile Tea",
                        menu: .chamomile,
                        desc: "Chamomile has anti-inflammatory and antioxidant properties that can help soothe a sore throat and calm coughing. It also promotes relaxation and sleep.",
                        img: "chamomile"
                    )
                ],
                relatedPharmacyRecords: [
                PharmacyCategories(
                    title: "Robitussin (Benylin)",
                    menu: .rob,
                    desc: "Robitussin is a cough suppressant that can provide relief from coughing associated with colds.",
                    img: "rob"
                ),
                PharmacyCategories(
                    title: "Halls Cough Drops",
                    menu: .hall,
                    desc: "Halls cough drops contain menthol, providing temporary relief from sore throat and cough.",
                    img: "hall"
                ),
                PharmacyCategories(
                    title: "Theraflu (DayQuil)",
                    menu: .raflu,
                    desc: "Theraflu is a combination medication that often includes pain relievers, decongestants, and cough suppressants to address multiple cold symptoms.",
                    img: "raflu"
                ),
                PharmacyCategories(
                    title: "Vicks VapoRub",
                    menu: .vicks,
                    desc: "Vicks VapoRub is a topical ointment applied to the chest and throat to provide relief from cough and congestion through its soothing vapors.",
                    img: "vicks"
                )
            ], relatedFitnessRecords: [
                FitnessCategories(
                    title: "Yoga",
                    menu: .yoga,
                    desc: "",
                    img: ""
                )
            ],
                relatedYogaRecords: [
                    MainCategories(
                           title: "Lion's Breath (Simhasana)",
                           menu: .lionsBreath,
                           desc: "A breathing exercise where you sit in a kneeling position, open your mouth wide, stick out your tongue, and exhale forcefully, helping to clear the throat and chest.",
                           img: "lionsBreath"
                       ),
                    MainCategories(
                            title: "Camel Pose (Ustrasana)",
                            menu: .camelPose,
                            desc: "A backbend where you kneel and reach back to grab your heels, opening the chest and throat, and stimulating circulation to alleviate coughing.",
                            img: "camelPose"
                        ),
                    MainCategories(
                            title: "Fish Pose (Matsyasana)",
                            menu: .fishPose,
                            desc: "A chest-opening pose where you lie on your back, lift your chest, and arch your back, relieving tension in the throat and promoting deep breathing.",
                            img: "fishPose"
                        ),
                    MainCategories(
                            title: "Standing Forward Bend",
                            menu: .standingForwardBend,
                            desc: "A forward fold where you hinge at the hips and reach for your feet, calming the mind and encouraging deeper breathing to alleviate coughing.",
                            img: "standingForwardBend"
                        )
                ],relatedExerciseRecords: [
                    MainCategories(
                        title: "Standing Leg Raises",
                        menu: .standLegRaise,
                        desc: "Perform standing leg raises to strengthen the core and improve balance without putting strain on the respiratory system.",
                        img: "standLegRaise"
                    ),
                    MainCategories(
                        title: "Arm Circles Exercise",
                        menu: .armCircle,
                        desc: "Engage in arm circles to gently warm up the shoulder joints and improve upper body mobility without exacerbating coughing symptoms.",
                        img: "armCircle"
                    ),
                    MainCategories(
                        title: "Bodyweight Squats",
                        menu: .bodSquats,
                        desc: "Execute bodyweight squats to strengthen the lower body muscles while maintaining a controlled breathing pattern to avoid triggering coughing fits.",
                        img: "bodSquats"
                    ),
                    MainCategories(
                        title: "Wall Push-Ups",
                        menu: .wallPushUps,
                        desc: "Perform wall push-ups to work the chest, shoulders, and arms with less pressure on the respiratory system compared to traditional push-ups.",
                        img: "wallPushUps"
                    )
                ]
        ),

            Illness.create(
                name: "Ulcers",
                desc: "Open sores in the mucous membranes of the body, often in the digestive tract.",
                symptoms: ["Pain", "Burning sensation", "Indigestion", "Abdominal Pain","Nausea", "Vomiting", "Bloating", "Loss of Appetite", "Weight Loss", "Bloody or Dark Stools", "Heartburn"],
                types: ["Peptic", "Gastric", "Esophageal","Mouth", "Stress", "Perforated"],
                preSick: false,
                bodyParts: ["Head", "Stomach"],
                feelings: [""],
                treatments: [""],
                prevention: [""],
                img: "",
                relatedHomemadeRecords: [
                    HomemadeCategories(
                        title: "Cabbage Juice",
                        menu: .cabbage,
                        desc: "Freshly juiced cabbage, known for its potential to soothe and heal stomach ulcers due to its anti-inflammatory properties.",
                        img: "cabbage"
                    ),
                    HomemadeCategories(
                        title: "Banana Smoothie",
                        menu: .banana,
                        desc: "A soothing smoothie made with ripe bananas, which may help coat and protect the stomach lining, providing relief for ulcers.",
                        img: "banana"
                    ),
                    HomemadeCategories(
                        title: "Honey-Lemon Water",
                        menu: .gingerMintTea,
                        desc: "A warm drink combining honey and lemon in water, believed to have antibacterial and soothing effects on stomach ulcers.",
                        img: "gingerMintTea"
                    ),
                    HomemadeCategories(
                        title: "Oatmeal with Almond Milk",
                        menu: .oat,
                        desc: "A comforting bowl of oatmeal made with almond milk, providing a bland and easily digestible option for individuals with stomach ulcers.",
                        img: "oat"
                    )
                ],
                relatedPharmacyRecords: [
                PharmacyCategories(
                    title: "Omeprazole",
                    menu: .omeprazole,
                    desc: "Omeprazole is a proton pump inhibitor (PPI) that reduces stomach acid production. It is used to treat conditions such as ulcers, gastroesophageal reflux disease (GERD), and certain stomach issues.",
                    img: "omeprazole"
                ),
                PharmacyCategories(
                    title: "Ranitidine",
                    menu: .ranitidine,
                    desc: "Ranitidine is an H2 blocker that reduces the amount of acid your stomach produces. It is commonly used to treat ulcers and conditions where the stomach produces too much acid.",
                    img: "ranitidine"
                ),
                PharmacyCategories(
                    title: "Sucralfate",
                    menu: .sucralfate,
                    desc: "Sucralfate is a medication that forms a protective coating over ulcers and damaged areas of the stomach lining, helping to promote healing and reduce discomfort.",
                    img: "sucralfate"
                ),
                PharmacyCategories(
                    title: "Antacid",
                    menu: .antacid,
                    desc: "Antacids containing calcium carbonate can help neutralize stomach acid and provide temporary relief from the symptoms of ulcers, such as heartburn and indigestion.",
                    img: "antacid"
                )
            ], relatedFitnessRecords: [
                FitnessCategories(
                    title: "Yoga",
                    menu: .yoga,
                    desc: "",
                    img: ""
                )
            ],
                relatedYogaRecords: [
                    MainCategories(
                            title: "Corpse Pose (Savasana)",
                            menu: .corpsePose,
                            desc: "A relaxation pose where you lie flat on your back with arms and legs extended, allowing your body to rest and promoting overall well-being.",
                            img: "corpsePose"
                        ),
                        MainCategories(
                            title: "Alternate Nostril Breath",
                            menu: .nostrilBreathing,
                            desc: "A pranayama technique involving alternating breaths through each nostril, balancing energy flow and calming the mind.",
                            img: "nostrilBreathing"
                        ),
                        MainCategories(
                            title: "Wind-Relieving Pose",
                            menu: .windRelievingPose,
                            desc: "A pose where you lie on your back and hug your knees into your chest, aiding digestion and relieving discomfort in the abdominal area.",
                            img: "windRelievingPose"
                        ),
                        MainCategories(
                            title: "Seated Spinal Twist",
                            menu: .matsyendrasana,
                            desc: "A seated twist where you twist your spine to each side, stimulating digestion and promoting the health of abdominal organs.",
                            img: "matsyendrasana"
                        )
                ],relatedExerciseRecords: [
                    MainCategories(
                        title: "Standing Calf Raises",
                        menu: .standCalf,
                        desc: "Stand and rise onto your toes, then lower back down, to strengthen the calf muscles without straining the abdomen.",
                        img: "standCalf"
                    ),
                    MainCategories(
                        title: "Gentle Stretching",
                        menu: .gentleYogaFlow,
                        desc: "Perform gentle stretching exercises to maintain flexibility and reduce muscle tension.",
                        img: "gentleYogaFlow"
                    ),
                    MainCategories(
                        title: "Deep Breathing",
                        menu: .pranayama,
                        desc: "Practice deep breathing techniques to promote relaxation and alleviate stress, which can help manage ulcer symptoms.",
                        img: "pranayama"
                    ),
                    MainCategories(
                        title: "Side Leg Lifts Exercise",
                        menu: .sideLegLifts,
                        desc: "Lie on your side and lift one leg at a time to strengthen the hip abductor muscles without aggravating ulcer symptoms.",
                        img: "sideLegLifts"
                    )
                ]
        ),

            Illness.create(
                name: "Food Poisoning",
                desc: "Illness caused by consuming contaminated food or water.",
                symptoms: ["Nausea", "Vomiting", "Diarrhea", "Abdominal pain or cramps", "Fever", "Muscle aches",  "Weakness", "Headache"],
                types: ["Bacterial", "Viral", "Parasitic", "Toxin-Mediated", "Allergic", "Chemical"],
                preSick: false,
                bodyParts: ["Stomach"],
                feelings: [""],
                treatments: [""],
                prevention: [""],
                img: "",
                relatedHomemadeRecords: [
                    HomemadeCategories(
                        title: "Rice Water Solution",
                        menu: .riceWater,
                        desc: "A simple solution made by boiling rice in water. Rice water helps soothe the digestive system and provides a source of easily digestible carbohydrates.",
                        img: "riceWater"
                    ),
                    HomemadeCategories(
                        title: "Banana and Yogurt",
                        menu: .banana,
                        desc: "A soothing smoothie made with ripe bananas and plain yogurt. Bananas are gentle on the stomach, and yogurt contains beneficial probiotics for digestive health.",
                        img: "banana"
                    ),
                    HomemadeCategories(
                        title: "Ginger Mint Tea",
                        menu: .gingerMintTea,
                        desc: "A herbal tea infusion with fresh ginger and mint leaves. Ginger aids digestion and may help alleviate nausea, while mint provides a refreshing flavor.",
                        img: "gingerMintTea"
                    ),
                    HomemadeCategories(
                        title: "Bland BRAT Diet",
                        menu: .bratDiet,
                        desc: "Following the BRAT diet – Bananas, Rice, Applesauce, and Toast. These bland foods are easy on the stomach and can help firm up stools during recovery.",
                        img: "bratDiet"
                    )
                ],
                relatedPharmacyRecords: [
                PharmacyCategories(
                    title: "Pepto-Bismol Syrup",
                    menu: .pepto,
                    desc: "Pepto-Bismol is an antidiarrheal and stomach soother that can help relieve symptoms like diarrhea, nausea, and upset stomach caused by food poisoning.",
                    img: "pepto"
                ),
                PharmacyCategories(
                    title: "Imodium (Loperamide)",
                    menu: .imodium,
                    desc: "Imodium is an antidiarrheal medication that helps control and reduce diarrhea symptoms caused by food poisoning.",
                    img: "imodium"
                ),
                PharmacyCategories(
                    title: "Activated Charcoal",
                    menu: .charcoal,
                    desc: "Activated charcoal can be used to absorb toxins in the digestive tract, helping alleviate symptoms of food poisoning like nausea and vomiting.",
                    img: "charcoal"
                ),
                PharmacyCategories(
                    title: "Electrolyte Solution",
                    menu: .electro,
                    desc: "Electrolyte solutions help replenish fluids and essential minerals lost due to vomiting and diarrhea caused by food poisoning, preventing dehydration.",
                    img: "electro"
                )

            ], relatedFitnessRecords: [
                FitnessCategories(
                    title: "Yoga",
                    menu: .yoga,
                    desc: "",
                    img: ""
                )
            ],
                relatedYogaRecords: [
                    MainCategories(
                            title: "Seated Spinal Twist",
                            menu: .seatedTwists,
                            desc: "A seated yoga pose where you twist your torso, massaging internal organs and aiding digestion, which can help alleviate discomfort caused by food poisoning.",
                            img: "seatedTwists"
                        ),
                        MainCategories(
                            title: "Corpse Pose (Savasana)",
                            menu: .corpsePose,
                            desc: "A relaxation pose where you lie flat on your back with arms and legs extended, allowing your body to rest and recover from the effects of food poisoning.",
                            img: "corpsePose"
                        ),
                        MainCategories(
                            title: "Extended Triangle Pose",
                            menu: .trianglePose,
                            desc: "A standing yoga pose that involves stretching the body sideways, stimulating digestion and relieving discomfort in the abdomen caused by food poisoning.",
                            img: "trianglePose"
                        ),
                        MainCategories(
                            title: "Child's Pose (Balasana)",
                            menu: .childsPoseHead,
                            desc: "A resting yoga pose where you sit back on your heels, stretch your arms forward, and lower your forehead to the ground, promoting relaxation and easing discomfort from food poisoning.",
                            img: "childsPoseHead"
                        )
                ],relatedExerciseRecords: [
                    MainCategories(
                        title: "Seated Twists Exercise",
                        menu: .seatedTwists,
                        desc: "Sit on the floor and perform seated twists to gently massage the abdominal organs and alleviate bloating or cramping.",
                        img: "seatedTwists"
                    ),
                    MainCategories(
                        title: "Pelvic Tilts Exercise",
                        menu: .pelvicTilts,
                        desc: "Lie on your back and perform pelvic tilts to relieve lower back pain and promote circulation in the abdominal area.",
                        img: "pelvicTilts"
                    ),
                    MainCategories(
                        title: "Leg Raises Exercise",
                        menu: .legRaise,
                        desc: "Perform leg raises to strengthen the core muscles and improve circulation, potentially aiding in digestion.",
                        img: "legRaise"
                    ),
                    MainCategories(
                        title: "Gentle Stretching",
                        menu: .gentleYogaFlow,
                        desc: "Perform gentle stretching exercises to relieve muscle tension and promote blood flow throughout the body.",
                        img: "gentleYogaFlow"
                    )
                ]
        ),

            Illness.create(
                name: "Diarrhea",
                desc: "Frequent, loose, or watery stools.",
                symptoms: ["Frequent bowel movements","Abdominal cramps","Bloody stools","Fever","Nausea"],
                types: ["Acute","Chronic","Infectious","Traveler's",
                    "IBD-related"
                ],
                preSick: true,
                bodyParts: ["Stomach"],
                feelings: [""],
                treatments: [""],
                prevention: [""],
                img: "",
                relatedHomemadeRecords: [
                    HomemadeCategories(
                        title: "Banana Rice Porridge",
                        menu: .bananaRice,
                        desc: "A simple porridge made with overripe bananas and white rice, which are easy to digest and can help firm up stools during diarrhea.",
                        img: "bananaRice"
                    ),
                    HomemadeCategories(
                        title: "Boiled Potatoes",
                        menu: .boiledPotatoes,
                        desc: "Boiled and mashed potatoes without added fats or spices, providing a bland and easily digestible option to ease diarrhea symptoms.",
                        img: "boiledPotatoes"
                    ),
                    HomemadeCategories(
                        title: "Ginger Mint Tea",
                        menu: .gingerMintTea,
                        desc: "A herbal tea infusion with fresh ginger and mint leaves. Ginger aids digestion and may help alleviate nausea, while mint provides a refreshing flavor.",
                        img: "gingerMintTea"
                    ),
                    HomemadeCategories(
                        title: "Homemade Electrolyte",
                        menu: .electrolyteSolution,
                        desc: "A homemade electrolyte solution with a mix of water, salt, and sugar to help prevent dehydration caused by diarrhea and replenish lost fluids.",
                        img: "electrolyteSolution"
                    )
                ],
                relatedPharmacyRecords: [
                    PharmacyCategories(
                        title: "Imodium (Loperamide)",
                        menu: .imodium,
                        desc: "Imodium is an over-the-counter medication used to treat diarrhea and reduce the frequency of bowel movements.",
                        img: "imodium"
                    ),
                    PharmacyCategories(
                        title: "Pepto Bismol Syrup",
                        menu: .pepto,
                        desc: "Pepto-Bismol is an antidiarrheal medication that can help relieve symptoms such as diarrhea, upset stomach, and indigestion.",
                        img: "pepto"
                    ),
                    PharmacyCategories(
                        title: "Bismuth Subsalicylate",
                        menu: .kaopectate,
                        desc: "Kaopectate is an antidiarrheal medication that helps treat diarrhea by coating the stomach and intestines, reducing irritation.",
                        img: "kaopectate"
                    ),
                    PharmacyCategories(
                        title: "Activated Charcoal",
                        menu: .charcoal,
                        desc: "Activated charcoal is a supplement that may help reduce diarrhea and absorb toxins in the digestive tract. It works by binding to substances in the digestive tract, preventing them from being absorbed into the body.",
                        img: "charcoal"
                    )
                ], relatedFitnessRecords: [
                    FitnessCategories(
                        title: "Yoga",
                        menu: .yoga,
                        desc: "",
                        img: ""
                    )
                ],
                    relatedYogaRecords: [
                        MainCategories(
                                title: "Seated Spinal Twist",
                                menu: .seatedTwists,
                                desc: "A seated yoga pose where you twist your torso to one side, stretching the spine and aiding digestion, which may help alleviate symptoms of diarrhea.",
                                img: "seatedTwists"
                            ),
                            MainCategories(
                                title: "Standing Forward Bend",
                                menu: .standingForwardBend,
                                desc: "A forward bending pose where you fold forward from the hips, relaxing the abdomen and promoting gentle compression on the digestive organs to ease diarrhea discomfort.",
                                img: "standingForwardBend"
                            ),
                            MainCategories(
                                title: "Wind-Relieving Pose",
                                menu: .windRelievingPose,
                                desc: "A yoga pose where you lie on your back and hug your knees into your chest, applying gentle pressure on the abdomen to help relieve gas and bloating associated with diarrhea.",
                                img: "windRelievingPose"
                            ),
                            MainCategories(
                                title: "Child's Pose (Balasana)",
                                menu: .childsPoseHead,
                                desc: "A resting yoga pose where you sit back on your heels and extend your arms forward, gently compressing the abdomen and promoting relaxation, which may aid in relieving diarrhea discomfort.",
                                img: "childsPoseHead"
                            )
                    ],relatedExerciseRecords: [
                        MainCategories(
                            title: "Neck Rolls Exercise",
                            menu: .neck,
                            desc: "Slowly roll the head in a circular motion, being mindful of any tension or discomfort in the neck muscles.",
                            img: "neck"
                        ),
                        MainCategories(
                            title: "Gentle Squats Exercise",
                            menu: .genSquats,
                            desc: "Perform shallow squats with a focus on maintaining good form and not exerting too much pressure on the abdominal area.",
                            img: "genSquats"
                        ),
                        MainCategories(
                            title: "Side Bends Exercise",
                            menu: .sideBends,
                            desc: "Stand with feet hip-width apart and gently bend to one side, then return to center and repeat on the other side to stretch the oblique muscles.",
                            img: "sideBends"
                        ),
                        MainCategories(
                            title: "Wrist Circles Exercise",
                            menu: .wristCircle,
                            desc: "Rotate the wrists in circular motions to promote flexibility and mobility in the wrist joints.",
                            img: "wristCircle"
                        )
                    ]
            ),

            Illness.create(
                name: "Arthritis",
                desc: "Inflammation of the joints, leading to pain and stiffness.",
                symptoms: ["Joint pain","Swelling","Stiffness","Warmth around joints",
                    "Redness at the joint","Limited range of motion"],
                types: ["Osteoarthritis","Rheumatoid","Ankylosing","Psoriatic",
                    "Gout"],
                preSick: false,
                bodyParts: ["Arms","Knees","Legs"],
                feelings: [""],
                treatments: [""],
                prevention: [""],
                img: "",
                relatedHomemadeRecords: [
                    HomemadeCategories(
                        title: "Turmeric Golden Milk",
                        menu: .goldenMilk,
                        desc: "A warm drink made with turmeric, black pepper, and milk, known for its anti-inflammatory properties that may provide relief for arthritis pain.",
                        img: "goldenMilk"
                    ),
                    HomemadeCategories(
                        title: "Omega-3 Rich Salmon Salad",
                        menu: .salmon,
                        desc: "A nutritious salad featuring omega-3 fatty acid-rich salmon, which has anti-inflammatory effects and may help reduce arthritis symptoms.",
                        img: "salmon"
                    ),
                    HomemadeCategories(
                        title: "Turmeric Ginger Water",
                        menu: .gingerLemonade,
                        desc: "A refreshing drink made by infusing water with ginger and turmeric, both known for their anti-inflammatory properties that may alleviate arthritis discomfort.",
                        img: "gingerLemonade"
                    ),
                    HomemadeCategories(
                        title: "Antioxidant Drinks",
                        menu: .ketogenic,
                        desc: "A delicious smoothie made with ingredients like berries, kale, and pineapple, rich in antioxidants and anti-inflammatory compounds that may support arthritis management.",
                        img: "ketogenic"
                    )
                ],
                relatedPharmacyRecords: [
                    PharmacyCategories(
                        title: "Celebrex (Celecoxib)",
                        menu: .celebrex,
                        desc: "Celebrex is a nonsteroidal anti-inflammatory drug (NSAID) used to treat pain, inflammation, and stiffness caused by arthritis.",
                        img: "celebrex"
                    ),
                    PharmacyCategories(
                        title: "Methotrexate (DMARD)",
                        menu: .methotrexate,
                        desc: "Methotrexate is a disease-modifying antirheumatic drug (DMARD) that can help treat rheumatoid arthritis and other autoimmune conditions.",
                        img: "methotrexate"
                    ),
                    PharmacyCategories(
                        title: "Tylenol Arthritis",
                        menu: .tylenolArthritis,
                        desc: "Tylenol Arthritis is formulated with acetaminophen to provide relief from pain associated with arthritis, without exacerbating inflammation.",
                        img: "tylenolArthritis"
                    ),
                    PharmacyCategories(
                        title: "Voltaren Gel (Diclofenac)",
                        menu: .voltarenGel,
                        desc: "Voltaren Gel is a topical NSAID that can be applied to the skin to relieve pain and inflammation in the joints caused by osteoarthritis or rheumatoid arthritis.",
                        img: "voltarenGel"
                    )
                ], relatedFitnessRecords: [
                    FitnessCategories(
                        title: "Yoga",
                        menu: .yoga,
                        desc: "",
                        img: ""
                    )
                ],
                    relatedYogaRecords: [
                        MainCategories(
                               title: "Gentle Yoga Flow",
                               menu: .gentleYogaFlow,
                               desc: "A slow and mindful yoga practice focusing on gentle movements and deep breathing to reduce joint stiffness and improve flexibility.",
                               img: "gentleYogaFlow"
                           ),
                           MainCategories(
                               title: "Seated Spinal Twist",
                               menu: .seatedTwists,
                               desc: "A seated yoga pose where you twist your spine gently, improving spinal mobility and relieving tension in the back and hips without putting stress on the knees.",
                               img: "seatedTwists"
                           ),
                           MainCategories(
                               title: "Supported Bridge Pose",
                               menu: .bridgePose,
                               desc: "Using props like a block or bolster, lie on your back and lift your hips slightly, gently stretching the lower back and hips to alleviate stiffness and discomfort.",
                               img: "bridgePose"
                           ),
                           MainCategories(
                               title: "Chair Yoga Pose",
                               menu: .chairYoga,
                               desc: "A modified yoga practice performed while seated or using a chair for support, offering gentle stretches and movements to increase circulation and reduce joint pain.",
                               img: "chairYoga"
                           )
                    ],relatedExerciseRecords: [
                        MainCategories(
                            title: "Knee Lifts Exercise",
                            menu: .kneeLifts,
                            desc: "Perform knee lifts while standing or seated to strengthen the hip flexors and improve overall lower body strength with minimal impact on the joints.",
                            img: "kneeLifts"
                        ),
                        MainCategories(
                            title: "Toe Taps Exercise",
                            menu: .toeTaps,
                            desc: "Tap your toes on the floor while seated or standing to improve ankle mobility and circulation without putting excessive strain on the joints.",
                            img: "toeTaps"
                        ),
                        MainCategories(
                            title: "Shoulder Squeezes",
                            menu: .shoulderBladeSqueeze,
                            desc: "Squeeze your shoulder blades together while seated or standing to improve posture and strengthen the upper back muscles without putting stress on the joints.",
                            img: "shoulderBladeSqueeze"
                        ),
                        MainCategories(
                            title: "Hip Circles Exercise",
                            menu: .hipCircle,
                            desc: "Rotate your hips in circular motions while standing or seated to improve hip mobility and reduce stiffness in the hip joints.",
                            img: "hipCircle"
                        )
                    ]
            ),

            Illness.create(
                name: "Malaria",
                desc: "Mosquito-borne infectious disease causing fever and chills.",
                symptoms: ["Fever","Chills","Sweating","Headache","Muscle aches",
                    "Nausea"],
                types: ["Falciparum","Vivax","Malariae",
                    "Ovale","Knowlesi"],
                preSick: false,
                bodyParts: ["Whole body"],
                feelings: [""],
                treatments: [""],
                prevention: [""],
                img: "",
                relatedHomemadeRecords: [
                    HomemadeCategories(
                        title: "Ginger-Lemon Herbal Tea",
                        menu: .gingerMintTea,
                        desc: "A soothing herbal tea made with fresh ginger and lemon, providing hydration and potential relief from nausea associated with malaria.",
                        img: "gingerMintTea"
                    ),
                    HomemadeCategories(
                        title: "Banana Oats Smoothie",
                        menu: .banana,
                        desc: "A nutritious smoothie made with bananas and oats, offering a soft and easily digestible option for individuals experiencing appetite loss during malaria.",
                        img: "banana"
                    ),
                    HomemadeCategories(
                        title: "Chicken Broth & Vegetables",
                        menu: .spicyChickenSoup,
                        desc: "A homemade chicken broth with added vegetables, providing essential nutrients, hydration, and warmth for individuals with malaria symptoms.",
                        img: "spicyChickenSoup"
                    ),
                    HomemadeCategories(
                        title: "Papaya and Honey Blend",
                        menu: .papayaHoneyBlend,
                        desc: "A blend of ripe papaya and honey, offering a source of vitamins and natural sweetness for energy during the recovery phase of malaria.",
                        img: "papayaHoneyBlend"
                    )
                ],
                relatedPharmacyRecords: [
                    PharmacyCategories(
                        title: "Chloroquine",
                        menu: .chloroquine,
                        desc: "Chloroquine is an antimalarial drug used to prevent and treat malaria. It works by killing the parasites causing the infection.",
                        img: "chloroquine"
                    ),
                    PharmacyCategories(
                        title: "ACT",
                        menu: .act,
                        desc: "ACT is a combination of artemisinin derivatives and other antimalarial drugs. It is highly effective against malaria and helps prevent resistance.",
                        img: "act"
                    ),
                    PharmacyCategories(
                        title: "Mefloquine",
                        menu: .mefloquine,
                        desc: "Mefloquine is an antimalarial medication used to prevent and treat malaria. It is particularly useful in areas with chloroquine-resistant malaria.",
                        img: "mefloquine"
                    ),
                    PharmacyCategories(
                        title: "Doxycycline",
                        menu: .doxycycline,
                        desc: "Doxycycline is an antibiotic that is also used for malaria prophylaxis. It inhibits the growth of malaria parasites in the bloodstream.",
                        img: "doxycycline"
                    )
                ], relatedFitnessRecords: [
                    FitnessCategories(
                        title: "Yoga",
                        menu: .yoga,
                        desc: "",
                        img: ""
                    )
                ],
                    relatedYogaRecords: [
                        MainCategories(
                                title: "Gentle Yoga Flow",
                                menu: .gentleYogaFlow,
                                desc: "A slow and mindful yoga practice focusing on gentle movements and deep breathing to reduce joint stiffness and improve flexibility",
                                img: "gentleYogaFlow"
                            ),
                            MainCategories(
                                title: "Seated Spinal Twist",
                                menu: .seatedTwists,
                                desc: "A seated yoga pose where you twist your spine gently, improving spinal mobility and relieving tension in the back and hips without putting stress on the knees",
                                img: "seatedTwists"
                            ),
                            MainCategories(
                                title: "Deep Breathing",
                                menu: .pranayama,
                                desc: "Engage in deep breathing exercises to enhance oxygenation and promote relaxation, supporting the body's immune system during malaria recovery.",
                                img: "pranayama"
                            ),
                            MainCategories(
                                title: "Corpse Pose (Savasana)",
                                menu: .corpsePose,
                                desc: "A relaxation pose where you lie on your back, allowing your body to rest and release tension, promoting overall relaxation and potential relief from malaria.",
                                img: "corpsePose"
                            )
                    ],relatedExerciseRecords: [
                        MainCategories(
                            title: "Hip Circles Exercise",
                            menu: .hipCircle,
                            desc: "Rotate your hips in circular motions while standing or seated to improve hip mobility and reduce stiffness in the hip joints.",
                            img: "hipCircle"
                        ),
                        MainCategories(
                            title: "Knee Lifts Exercise",
                            menu: .kneeLifts,
                            desc: "Perform knee lifts while standing or seated to strengthen the hip flexors and improve overall lower body strength with minimal impact on the joints.",
                            img: "kneeLifts"
                        ),
                        MainCategories(
                            title: "Toe Taps Exercise",
                            menu: .toeTaps,
                            desc: "Tap your toes on the floor while seated or standing to improve ankle mobility and circulation without putting excessive strain on the joints.",
                            img: "toeTaps"
                        ),
                        MainCategories(
                            title: "Gentle Stretching",
                            menu: .gentleYogaFlow,
                            desc: "Engage in gentle stretching routines to release tension in the muscles and improve circulation, potentially reducing feelings of discomfort.",
                            img: "gentleYogaFlow"
                        )
                    ]
                ),
           ]
       }

    func searchIllness(byName name: String) -> Illness? {
            return illnesses.first { $0.name.lowercased().contains(name.lowercased()) }
    }
}

