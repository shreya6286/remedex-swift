//
//  Illness.swift
//  Remedex
//
//  Created by Shreya Bhavsar on 15/01/24.
//

import Foundation

struct Illness: Identifiable {
    var id = UUID()
    var name: String
    var desc: String
    var symptoms: [String]
    var types: [String]
    var preSick: Bool
    var bodyParts: [String]
    var feelings: [String]
    var treatments: [String]
    var prevention: [String]
    var img: String
    var relatedPharmacyRecords: [PharmacyCategories]
    var relatedHomemadeRecords: [HomemadeCategories]
    var relatedFitnessRecords: [FitnessCategories]
    var relatedYogaRecords: [MainCategories]
    var relatedExerciseRecords: [MainCategories]
}

struct PharmacyRecords: Codable, Identifiable {
    var id: UUID = UUID()
    var name: String = ""
    var desc: String = ""
    var use_cases: String = ""
    var img: String = ""
}

struct PharmacyCategories: Identifiable, Hashable {
    var id = UUID()
    var title: String
    var menu: PharmacyMenu
    var desc: String
    var img: String
}

struct HomemadeRecords: Codable, Identifiable {
    var id: UUID = UUID()
    var name: String = ""
    var desc: String = ""
    var use_cases: String = ""
    var img: String = ""
}

struct HomemadeCategories: Identifiable, Hashable {
    var id = UUID()
    var title: String
    var menu: HomemadeMenu
    var desc: String
    var img: String
}

struct FitnessRecords {
    var id: UUID = UUID()
    var name: String = ""
    var desc: String = ""
    var use_cases: String = ""
    var img: String = ""
}

struct FitnessCategories: Identifiable, Hashable {
    var id = UUID()
    var title: String
    var menu: FitMenu
    var desc: String
    var img: String
}

struct MainCategories: Identifiable, Hashable {
    var id = UUID()
    var title: String
    var menu: MainMenu
    var desc: String
    var img: String
}

extension Illness {
    static func create(name: String, desc: String, symptoms: [String], types: [String], preSick: Bool, bodyParts: [String], feelings: [String], treatments: [String], prevention: [String], img: String, relatedHomemadeRecords: [HomemadeCategories],
        relatedPharmacyRecords: [PharmacyCategories],
        relatedFitnessRecords: [FitnessCategories],
        relatedYogaRecords: [MainCategories], relatedExerciseRecords: [MainCategories]) -> Illness
        {
            return Illness(name: name, desc: desc, symptoms: symptoms, types: types, preSick: preSick, bodyParts: bodyParts, feelings: feelings, treatments: treatments, prevention: prevention, img: img, relatedPharmacyRecords: relatedPharmacyRecords, relatedHomemadeRecords: relatedHomemadeRecords, relatedFitnessRecords: relatedFitnessRecords, relatedYogaRecords: relatedYogaRecords, relatedExerciseRecords: relatedExerciseRecords)
        }
}

