import SwiftUI

struct StartingContentView: View {
    @State var show = false
    var body: some View {
        NavigationView {
            ZStack {
                VStack {
                    Image("logo")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: 200)
                        .padding()
                    Spacer()
                    Text("The Right Choice For Your 👩🏻 👨🏻 Health Care Needs")
                        .font(.system(size: 40))
                        .bold()
                        .padding(.top)
                    Spacer()
                    Image("launch1")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .padding(.bottom)
                    NavigationLink(destination: PersonalInfo1View()) {
                        Capsule()
                            .foregroundColor(Color(red: 0.058823529411764705, green: 0.08235294117647059, blue: 0.16862745098039217))
                            .frame(height: 80)
                            .overlay(
                                Text("Get Started")
                                    .foregroundColor(.white)
                                    .font(.system(size: 20))
                            )
                    }
                }
            }
            .padding()
        }
        .tint(.blue)
    }
}

struct Previews_ContentView_Previews: PreviewProvider {
    static var previews: some View {
        let personalRecords = PersonalRecords()
        return StartingContentView()
            .environmentObject(personalRecords)
    }
}
