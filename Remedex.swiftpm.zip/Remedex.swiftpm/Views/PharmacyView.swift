//
//  PharmacyView.swift
//  Remedex
//
//  Created by Shreya Bhavsar on 27/01/24.
//

import SwiftUI

struct PharmacyView: View {
    @State public var selectedPharmacy: PharmacyCategories?
    @State public var isActive: Bool = false
    var pharArray: [PharmacyCategories]
    init(pharArray: [PharmacyCategories]) {
            self.pharArray = pharArray
            UINavigationBar.appearance().backgroundColor = UIColor.red
        }
    let customColor = Color(red: 1, green: 0.9176470588235294, blue: 0.8235294117647058)
    var body: some View {
        ZStack {
            Color(.systemGray6)
            VStack {
                VStack(alignment: .leading) {
                    VStack {
                        HStack {
                            Image(systemName: "exclamationmark.triangle")
                            Text("Warning!")
                                .bold()
                            Spacer()
                        }
                        .font(.system(size: 25))
                        Text("Please contact a licensed medical practitioner before using any of the suggested medicines and their doses.")
                            .padding(.top, 2)
                    }
                    .padding()
                }
                .background(
                    RoundedRectangle(cornerRadius: 10)
                        .foregroundColor(customColor)
                )
                .padding(.horizontal, 10)
                .padding(.top, 10)
                ScrollView {
                    LazyVGrid(columns: [GridItem(.flexible(), spacing: 16), GridItem(.flexible(), spacing: 16)], spacing: 16) {
                        ForEach(pharArray) { item in
                            Button(action: {
                                selectedPharmacy = item
                                isActive = true
                            }) {
                                HStack {
                                    Spacer()
                                    VStack(alignment: .leading) {
                                        HStack {
                                            Spacer()
                                            Image("\(item.img)")
                                                .resizable()
                                                .aspectRatio(contentMode: .fit)
                                                .frame(height: 100)
                                            Spacer()
                                        }
                                        Text("\(item.title)")
                                            .bold()
                                            .font(.system(size: 18))
                                            .padding(.bottom, -10)
                                            .foregroundColor(.black)
                                    }
                                    Spacer()
                                }
                                .padding()
                                .background(Color.white)
                                .cornerRadius(10)
                            }
                        }
                    }
                    .padding(16)
                }
                .background(
                    NavigationLink("", destination: pharmacyDestination(for: selectedPharmacy), isActive: $isActive)
                        .hidden()
                )
            }
            .navigationBarColor(UIColor.systemGray6)
        }
    }
    func pharmacyDestination(for item: PharmacyCategories?) -> some View {
        if let item = item {
            switch item.menu {
            case  .excedrin, .vicks, .aleve, .tylenol, .advil, .zofran, .amitriptyline, .nascrom, .afrin, .saline, .vaseline, .dayNyQuil, .tylenolColdFlu, .ricola, .chloraseptic, .raflu, .rob, .hall, .omeprazole, .antacid, .ranitidine, .sucralfate, .pepto, .imodium, .charcoal, .electro, .kaopectate, .celebrex, .methotrexate, .tylenolArthritis, .voltarenGel, .chloroquine, .act, .mefloquine, .doxycycline:
                
                return AnyView(CommonPharmacyView(selectedPharmacy: selectedPharmacy))
            }
        } else {
            return AnyView(EmptyView())
        }
    }
}

enum PharmacyMenu: String {
    case tylenol
    case advil
    case excedrin
    case aleve
    case vicks
    case zofran
    case amitriptyline
    case afrin
    case nascrom
    case saline
    case vaseline
    case tylenolColdFlu
    case dayNyQuil
    case chloraseptic
    case ricola
    case raflu
    case rob
    case hall
    case omeprazole
    case ranitidine
    case sucralfate
    case antacid
    case pepto
    case imodium
    case charcoal
    case electro
    case kaopectate
    case voltarenGel
    case tylenolArthritis
    case celebrex
    case methotrexate
    case act
    case mefloquine
    case doxycycline
    case chloroquine
}

struct CommonPharmacyView: View {
    var selectedPharmacy: PharmacyCategories?
    @State var isActive: Bool = false
    init() {
            UINavigationBar.appearance().backgroundColor = UIColor.red
    }
    init(selectedPharmacy: PharmacyCategories?) {
            self.selectedPharmacy = selectedPharmacy
    }
        var body: some View {
            ZStack {
                Color(.systemGray6)
                ScrollView {
                    VStack {
                        if let selectedPharmacy = selectedPharmacy {
                            VStack(alignment: .leading) {
                                HStack {
                                    Spacer()
                                    Image("\(selectedPharmacy.img)")
                                        .resizable()
                                        .aspectRatio(contentMode: .fit)
                                        .padding()
                                        .frame(height: 300)
                                    Spacer()
                                }
                                .padding()
                                .background(Color.white)
                                .cornerRadius(10)
                                Text("\(selectedPharmacy.title)")
                                    .bold()
                                    .font(.system(size: 30))
                                Text("\(selectedPharmacy.desc)")
                                    .padding(.top, 3)
                            }
                        } else {
                            Text("No pharmacy selected")
                        }
                    }
                    .padding()
                }
            }
            .navigationBarColor(UIColor.systemGray6)
        }
}


