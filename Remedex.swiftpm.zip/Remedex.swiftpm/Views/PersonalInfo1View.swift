//
//  PersonalInfo1View.swift
//  Remedex
//
//  Created by Shreya Bhavsar on 27/01/24.
//

import SwiftUI

struct PersonalInfo1View: View {

    @State var showErrorMessage = false
    @EnvironmentObject var personalRecords: PersonalRecords

    var body: some View {
        ZStack {
            VStack {
                VStack {
                    Image("heartLogo")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: 120)
                    HStack {
                        Text("Intake Interview")
                            .font(.system(size: 25))
                            .bold()
                        Spacer()
                        Text("1/2")
                            .font(.system(size: 20))
                            .bold()
                    }
                    ProgressView(value: 0.5)
                    HStack {
                        Text("Enter personal information")
                            .padding(.top, 10)
                            .padding(.bottom, 10)
                            .multilineTextAlignment(.leading)
                        Spacer()
                    }
                }
                .padding()
                .background(Color(red: 0.6784313725490196, green: 0.8470588235294118, blue: 1)
                    .opacity(0.7)
                    .ignoresSafeArea())
                .clipShape(RoundedRectangle(cornerRadius: 15))
                Spacer()

                TextField("Enter first name", text: $personalRecords.firstName)
                    .font(.system(size: 20))
                    .foregroundColor(.black)
                    .padding(.all, 13)
                    .background(Color.white)
                    .overlay(
                        RoundedRectangle(cornerRadius: 10)
                            .stroke(Color(red: 0.6784313725490196, green: 0.8470588235294118, blue: 1), lineWidth: 2)
                    )
                    .padding(.bottom, 5)
                
                TextField("Enter last name", text: $personalRecords.lastName)
                    .font(.system(size: 20))
                    .foregroundColor(.black)
                    .padding(.all, 13)
                    .overlay(
                        RoundedRectangle(cornerRadius: 10)
                            .stroke(Color(red: 0.6784313725490196, green: 0.8470588235294118, blue: 1), lineWidth: 2)
                    )
                    .padding(.bottom, 5)
                
                TextField("Enter email address", text: $personalRecords.email)
                    .font(.system(size: 20))
                    .padding(.all, 13)
                    .overlay(
                        RoundedRectangle(cornerRadius: 10)
                            .stroke(Color(red: 0.6784313725490196, green: 0.8470588235294118, blue: 1), lineWidth: 2)
                    )
                    .textContentType(.emailAddress)
                    .disableAutocorrection(true)
                    .textInputAutocapitalization(.never)
                    .foregroundColor(personalRecords.email.isValidEmail ? .black : .red)
                    .padding(.bottom, 5)
                
                TextField("Enter 10 phone no.", text: $personalRecords.phoneNumber)
                    .font(.system(size: 20))
                    .foregroundColor(personalRecords.phoneNumber.isValidPhone ? .black : .red)
                    .padding(.all, 13)
                    .overlay(
                        RoundedRectangle(cornerRadius: 10)
                            .stroke(Color(red: 0.6784313725490196, green: 0.8470588235294118, blue: 1), lineWidth: 2)
                    )
    
                Spacer()

                if personalRecords.firstName == "" || personalRecords.lastName == "" || personalRecords.email == "" || personalRecords.phoneNumber == "" || !personalRecords.email.isValidEmail || !personalRecords.phoneNumber.isValidPhone {
                    Button(action: {
                        if self.personalRecords.firstName == ""  || self.personalRecords.lastName == "" || self.personalRecords.email == "" || self.personalRecords.phoneNumber == "" {
                                self.showErrorMessage = true
                        }
                    }, label: {
                        Capsule()
                            .foregroundColor(Color(red: 0.058823529411764705, green: 0.08235294117647059, blue: 0.16862745098039217))
                            .frame(height: 60)
                            .overlay(
                                Text("Next")
                                    .foregroundColor(.white)
                                    .font(.system(size: 20))
                                    .padding()
                            )
                    })
                } else {
                    NavigationLink(destination: PersonalInfo2View()){
                        Capsule()
                            .foregroundColor(Color(red: 0.058823529411764705, green: 0.08235294117647059, blue: 0.16862745098039217))
                            .frame(height: 60)
                            .overlay(
                                Text("Next")
                                    .foregroundColor(.white)
                                    .font(.system(size: 20))
                                    .padding()
                            )
                    }
                }
            }
            .alert(isPresented: $showErrorMessage) { () -> Alert in
                Alert(title: Text("Alert"), message: Text("Please fill all the fields"), primaryButton: .default(Text("Ok")), secondaryButton: .destructive(Text("Cancel")))
               
            }
            .padding()
        }
    }
}

extension String {
    var isValidEmail: Bool {
        NSPredicate(format: "SELF MATCHES %@", "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}").evaluate(with: self)
    }
}

extension String {
    var isValidPhone: Bool {
        NSPredicate(format: "SELF MATCHES %@", #"^\+?[0-9]{1,4}[-\s\.]?(\([0-9]+\)|[0-9]+)[-\. ]?[0-9]{1,5}[-\. ]?[0-9]{1,5}$"#).evaluate(with: self)
    }
}

struct PersonalInfo1View_Previews: PreviewProvider {
    static var previews: some View {
        let personalRecords = PersonalRecords()
        return PersonalInfo1View()
            .environmentObject(personalRecords)
    }
}

