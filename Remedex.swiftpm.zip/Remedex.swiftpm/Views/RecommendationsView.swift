//
//  RecommendationsView.swift
//  Remedex
//
//  Created by Shreya Bhavsar on 27/01/24.
//

import SwiftUI

struct RecommendationsView: View {
    let illness: Illness
    @State private var selectedItem: NavigationItem?
    @State private var isActive: Bool = false
    let customColor = Color(red: 0.9568627450980393, green: 0.9725490196078431, blue: 0.8431372549019608)
    @State private var animate = false
    var body: some View {
        VStack {
            VStack(alignment: .leading) {
                VStack {
                    HStack {
                        Image(systemName: "heart")
                        Text("Recovery strategies")
                            .bold()
                        Spacer()
                    }
                    .font(.system(size: 25))
                    Text("Only some of the common practices are provided for treating \(illness.name).")
                        .padding(.top, 2)
                }
                .padding()
            }
            .background(
                RoundedRectangle(cornerRadius: 10)
                    .foregroundColor(customColor)
            )
            .padding(.horizontal, 10)
            .padding(.top, 10)
            List(navigationItems) { item in
                Section {
                    Button(action: {
                        selectedItem = item
                        isActive = true
                    }) {
                        HStack {
                            Image("\(item.img)")
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .frame(height: 110)
                                .clipShape(RoundedRectangle(cornerRadius: 10))
                            VStack {
                                Text("\(item.title)")
                                    .bold()
                                    .font(.system(size: 18))
                                    .padding(.top, -10)
                                    .foregroundColor(.black)
                                Text("\(item.desc)")
                                    .padding(.all, 1)
                                    .font(.system(size: 14))
                                    .foregroundColor(.black)
                            }
                            VStack {
                                Spacer()
                                Image(systemName: "arrow.forward.circle")
                            }
                        }
                        .padding(.all, 5)
                    }
                }
            }
            .clipShape(RoundedRectangle(cornerRadius: 5))
            .listStyle(PlainListStyle())
            
            NavigationLink(destination: AnalyticsView(illness: illness)) {
                Capsule()
                    .foregroundColor(.orange)
                    .opacity(0.6)
                    .frame(height: 60)
                    .overlay(
                        Text("View Report")
                            .foregroundColor(.black)
                            .font(.system(size: 20))
                            .padding()
                    )
            }
            .padding()
        }
        .background(
            NavigationLink("", destination: destination(for: selectedItem), isActive: $isActive)
                .hidden()
        )
    }

    func destination(for item: NavigationItem?) -> some View {
        if let item = item {
            switch item.menu {
            case .pharmacy:
                return AnyView(PharmacyView(pharArray: illness.relatedPharmacyRecords))
            case .homemade:
                return AnyView(HomemadeView(homeArray: illness.relatedHomemadeRecords))
            case .fitness:
                return AnyView(FitnessView(illness: illness))
            }
        } else {
            return AnyView(EmptyView())
        }
    }
}

struct NavigationItem: Identifiable, Hashable {
    var id = UUID()
    var title: String
    var menu: Menu
    var desc: String
    var img: String
}

var navigationItems = [
    NavigationItem(title: "Modern Medicine 💊", menu: .pharmacy, desc: "Pills & other medicines recommended by doctors.", img: "pharm1"),
    NavigationItem(title: "Homemade Hacks 🍯", menu: .homemade, desc: "Restore your health naturally and effectively.", img: "juice1"),
    NavigationItem(title: "Fitness Routines   👟", menu: .fitness, desc: "Easy workouts to keep your health in order.", img: "fit")
]

enum Menu: String {
    case pharmacy
    case homemade
    case fitness
}


struct RecommendationsView_Previews: PreviewProvider {
    static var previews: some View {
        let personalRecords = PersonalRecords()
        let sampleIllness = Illness(name: "Sample Illness", desc: "Sample description", symptoms: ["Symptom 1", "Symptom 2"], types: ["Type 1"], preSick: false, bodyParts: ["Body Part"], feelings: ["Feeling"], treatments: ["Treatment"], prevention: ["Prevention"], img: "sample_image", relatedPharmacyRecords: [ PharmacyCategories(
            title: "Vicks VapoRub",
            menu: .vicks,
            desc: "icks VapoRub is a topical ointment applied to the chest and throat to provide relief from cough and congestion through its soothing vapors.",
            img: "fit"
        )], relatedHomemadeRecords: [HomemadeCategories(
            title: "Vicks VapoRub",
            menu: .peppermint,
            desc: "icks VapoRub is a topical ointment applied to the chest and throat to provide relief from cough and congestion through its soothing vapors.",
            img: "fit"
        )], relatedFitnessRecords: [
            FitnessCategories(
                title: "Yoga",
                menu: .yoga,
                desc: "",
                img: ""
                ), FitnessCategories(
                    title: "Exercise",
                    menu: .exercise,
                    desc: "",
                    img: ""
                )
            ],relatedYogaRecords: [
                MainCategories(
                    title: "Child's Pose (Balasana)",
                    menu: .childsPoseHead,
                    desc: "A",
                    img: "migraine1"
                ),
                MainCategories(
                    title: "Downward",
                    menu: .corpsePose,
                    desc: "A",
                    img: "migraine2"
                ),
                MainCategories(
                    title: "Seated",
                    menu: .childsPoseHead,
                    desc: "A",
                    img: "migraine3"
                ),
                MainCategories(
                    title: "Alternate",
                    menu: .childsPoseHead,
                    desc: "A",
                    img: "migraine4"
                )
            ],relatedExerciseRecords: [
                MainCategories(
                    title: "Child's Pose (Balasana)",
                    menu: .childsPoseHead,
                    desc: "A",
                    img: "migraine1"
                ),
                MainCategories(
                    title: "Downward",
                    menu: .plank,
                    desc: "A",
                    img: "migraine2"
                ),
                MainCategories(
                    title: "Seated",
                    menu: .childsPoseHead,
                    desc: "A",
                    img: "migraine3"
                ),
                MainCategories(
                    title: "Alternate",
                    menu: .childsPoseHead,
                    desc: "A",
                    img: "migraine4"
                )
            ]
        )

        NavigationView {
            return RecommendationsView(illness: sampleIllness)
                .environmentObject(personalRecords)
        }
    }
}

