//
//  FitnessView.swift
//  Remedex
//
//  Created by Shreya Bhavsar on 27/01/24.
//

import SwiftUI

struct FitnessView: View {
    let illness: Illness
    @State private var selectedFit: FitnessCategories?
    @State private var isActive: Bool = false
    let customColor = Color(red: 1, green: 0.8705882352941177, blue: 0.9098039215686274)
    var body: some View {
        ZStack {
            Color(.systemGray6)
            VStack(alignment: .leading) {
                VStack(alignment: .leading) {
                    VStack {
                        HStack {
                            Image(systemName: "dumbbell")
                            Text("What kind of fitness are you into?")
                                .bold()
                            Spacer()
                        }
                        .font(.system(size: 23))
                        Text("Only some of the common exercises are provided for treating \(illness.name).")
                            .padding(.top, 2)
                    }
                    .padding()
                }
                .background(
                    RoundedRectangle(cornerRadius: 10)
                        .foregroundColor(customColor)
                )
                .padding(.horizontal, 10)
                .padding(.top, 100)
                List(fitnessCategories) { item in
                    Section {
                        Button(action: {
                            selectedFit = item
                            isActive = true
                        }) {
                            HStack {
                                Image("\(item.img)")
                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                                    .frame(height: 110)
                                    .clipShape(RoundedRectangle(cornerRadius: 10))
                                VStack {
                                    HStack {
                                        Text("\(item.title)")
                                            .bold()
                                            .font(.system(size: 18))
                                            .padding(.leading, 10)
                                            .padding(.top, -10)
                                            .padding(.bottom, 1)
                                            .foregroundColor(.black)
                                        Spacer()
                                    }
                                    Text("\(item.desc)")
                                        .font(.system(size: 14))
                                        .foregroundColor(.black)
                                }
                                VStack {
                                    Spacer()
                                    Image(systemName: "arrow.forward.circle")
                                }
                            }
                            .padding(.all, 5)
                        }
                    }
                }
                
            }
            .background(
                NavigationLink("", destination: fitDestination(for: selectedFit), isActive: $isActive)
                    .hidden()
            )
            .listStyle(InsetListStyle())
            .background(.white)
        }
        .ignoresSafeArea()
    }
    
    func fitDestination(for item: FitnessCategories?) -> some View {
        if let item = item {
            switch item.menu {
            case .yoga:
                return AnyView(YogaView(illness: illness))
            case .exercise:
                return AnyView(ExerciseView(illness: illness))
            }
        } else {
            return AnyView(EmptyView())
        }
    }
}

var fitnessCategories = [
    FitnessCategories(title: "Yoga 🧘🏻‍♀️", menu: .yoga, desc: "Easy yoga workouts to keep your health in order.", img: "yoga"),
    FitnessCategories(title: "Exercises 🏃🏻‍♀️", menu: .exercise, desc: "Easy exercises to keep your health in order.", img: "exe"),
]

enum FitMenu: String {
    case yoga
    case exercise
}

extension View {
    func navigationBarColor(_ color: UIColor?) -> some View {
        self.modifier(NavigationBarModifier(backgroundColor: color))
    }
}
struct NavigationBarModifier: ViewModifier {
    var backgroundColor: UIColor?

    init(backgroundColor: UIColor?) {
        self.backgroundColor = backgroundColor
        let coloredAppearance = UINavigationBarAppearance()
        coloredAppearance.configureWithTransparentBackground()
        coloredAppearance.backgroundColor = backgroundColor
        coloredAppearance.titleTextAttributes = [.foregroundColor: UIColor.white]
        coloredAppearance.largeTitleTextAttributes = [.foregroundColor: UIColor.white]

        UINavigationBar.appearance().standardAppearance = coloredAppearance
        UINavigationBar.appearance().scrollEdgeAppearance = coloredAppearance
        UINavigationBar.appearance().compactAppearance = coloredAppearance
    }

    func body(content: Content) -> some View {
        content
    }
}

struct CommonWellnessView: View {
    @State public var selectedMain: MainCategories?
    @State public var isActive: Bool = false
    var medArray: [MainCategories]
    init(medArray: [MainCategories]) {
            self.medArray = medArray
            UINavigationBar.appearance().backgroundColor = UIColor.red
        }
        var body: some View {
            ZStack {
                Color(.systemGray6)
                ScrollView {
                    LazyVGrid(columns: [GridItem(.flexible(), spacing: 16), GridItem(.flexible(), spacing: 16)], spacing: 16) {
                        ForEach(medArray) { item in
                            Button(action: {
                                selectedMain = item
                                isActive = true
                            }) {
                                    HStack {
                                        Spacer()
                                        VStack(alignment: .leading) {
                                            HStack {
                                                Spacer()
                                                Image("\(item.img)")
                                                    .resizable()
                                                    .aspectRatio(contentMode: .fit)
                                                    .frame(height: 100)
                                                Spacer()
                                            }
                                            Text("\(item.title)")
                                                .bold()
                                                .font(.system(size: 18))
                                                .padding(.bottom, -10)
                                                .foregroundColor(.black)
                                        }
                                        Spacer()
                                    }
                                    .padding()
                                    .background(Color.white)
                                    .cornerRadius(10)
                                }
                        }
                    }
                    .padding(16)
                }
                .background(
                    NavigationLink("", destination: meditationDestination(for: selectedMain), isActive: $isActive)
                        .hidden()
                )
            }
            .navigationBarColor(UIColor.systemGray6)
        }
    
    func meditationDestination(for item: MainCategories?) -> some View {
        if let item = item {
            switch item.menu {
            case .catCow, .trianglePose, .corpsePose, .pranayama, .netiPot, .bridgePose, .nostrilBreathing, .childsPoseHead, .neckStretches, .seatedTwists, .forwardFold, .kapalbhatiPranayama, .sheetkariPranayama, .legsUpWall, .sitaliPranayama, .windRelievingPose, .camelPose, .fishPose, .standingForwardBend, .lionsBreath, .matsyendrasana, .gentleYogaFlow, .chairYoga, .neck, .pressure, .shoulderRolls, .pilates, .legRaise, .modPushUps, .plank, .plankVar, .bodLunges, .bodSquats, .standLegRaise, .wallPushUps, .chairDips, .seatedLegLifts, .pushUps, .jumpJacks, .armCircle, .standCalf, .sideLegLifts, .pelvicTilts, .genSquats, .sideBends, .wristCircle, .hipCircle, .shoulderBladeSqueeze, .toeTaps, .kneeLifts:
                return AnyView(CommonPosesView(selectedMain: selectedMain))
            }
        } else {
            return AnyView(EmptyView())
        }
    }

}

struct YogaView: View {
    let illness: Illness
    var body: some View {
        CommonWellnessView(medArray: illness.relatedYogaRecords)
    }
}

struct ExerciseView: View {
    let illness: Illness
    var body: some View {
        CommonWellnessView(medArray: illness.relatedExerciseRecords)
    }
}

enum MainMenu: String {
    case catCow
    case trianglePose
    case corpsePose
    case pranayama
    case nostrilBreathing
    case netiPot
    case bridgePose
    case seatedTwists
    case neckStretches
    case forwardFold
    case childsPoseHead
    case sitaliPranayama
    case legsUpWall
    case sheetkariPranayama
    case kapalbhatiPranayama
    case windRelievingPose
    case lionsBreath
    case standingForwardBend
    case fishPose
    case camelPose
    case matsyendrasana
    case gentleYogaFlow
    case chairYoga
    
    
    
    case toeTaps
    case kneeLifts
    case pelvicTilts
    case shoulderBladeSqueeze
    case hipCircle
    case standLegRaise
    case seatedLegLifts
    case sideLegLifts
    case standCalf
    case pushUps
    case wristCircle
    case jumpJacks
    case genSquats
    case sideBends
    case armCircle
    case chairDips
    case wallPushUps
    case legRaise
    case plank
    case plankVar
    case bodSquats
    case bodLunges
    case modPushUps
    case pilates
    case neck
    case shoulderRolls
    case pressure
}

struct CommonPosesView: View {
    var selectedMain: MainCategories?
    @State var isActive: Bool = false
    init() {
            UINavigationBar.appearance().backgroundColor = UIColor.red
    }
    init(selectedMain: MainCategories?) {
            self.selectedMain = selectedMain
    }
        var body: some View {
            ZStack {
                Color(.systemGray6)
                ScrollView {
                    VStack {
                        if let selectedMain = selectedMain {
                            VStack(alignment: .leading) {
                                HStack {
                                    Spacer()
                                    Image("\(selectedMain.img)")
                                        .resizable()
                                        .aspectRatio(contentMode: .fit)
                                        .padding()
                                        .frame(height: 300)
                                    Spacer()
                                }
                                .padding()
                                .background(Color.white)
                                .cornerRadius(10)
                                Text("\(selectedMain.title)")
                                    .bold()
                                    .font(.system(size: 30))
                                Text("\(selectedMain.desc)")
                                    .padding(.top, 3)
                            }
                        } else {
                            Text("No pose selected")
                        }
                    }
                    .padding()
                }
            }
            .navigationBarColor(UIColor.systemGray6)
        }
}
