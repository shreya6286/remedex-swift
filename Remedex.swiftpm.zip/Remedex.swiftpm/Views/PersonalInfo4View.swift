//
//  PersonalInfo4View.swift
//  Remedex
//
//  Created by Shreya Bhavsar on 27/01/24.
//



import SwiftUI

struct PersonalInfo4View: View {
    let illness: Illness
    @State private var selectedSymptoms: Set<String> = []
    let customColor = Color(red: 0.9568627450980393, green: 0.9725490196078431, blue: 0.8431372549019608)
    @State var showErrorMessage = false
    @EnvironmentObject var personalRecords: PersonalRecords

    var body: some View {
        ZStack {
            Color(red: 0.6784313725490196, green: 0.8470588235294118, blue: 1)
                .ignoresSafeArea()
            VStack {
                VStack(alignment: .leading) {
                    HStack {
                        Image(systemName: "doc.text")
                        Text("\(illness.name)")
                            .bold()
                        Spacer()
                    }
                    .font(.system(size: 25))
                    Text("\(illness.desc)")
                        .padding(.top, 2)
                }
                .padding(.all, 20)
                .background(
                    RoundedRectangle(cornerRadius: 10)
                        .foregroundColor(customColor)
//                        .opacity(0.15)
                )
                
                VStack(alignment: .leading) {
                    HStack {
                        Text("Common signs & symptoms")
                            .font(.system(size: 20))
                            .bold()
                        Spacer()
                    }
                    TagsSelectionLayout(illnesses: [illness], selectedSymptoms: $selectedSymptoms)
                }
                .padding()
                .background(
                    RoundedRectangle(cornerRadius: 10)
                        .foregroundColor(.white)
                )
                .padding(.bottom, 20)
                Spacer()
                if selectedSymptoms == [] {
                    Button(action: {
                        if self.selectedSymptoms == [] {
                                self.showErrorMessage = true
                        }
                    }, label: {
                        Capsule()
                            .foregroundColor(Color(red: 0.058823529411764705, green: 0.08235294117647059, blue: 0.16862745098039217))
                            .frame(height: 60)
                            .overlay(
                                Text("Next")
                                    .foregroundColor(.white)
                                    .font(.system(size: 20))
                                    .padding()
                            )
                    })
                } else {
                    NavigationLink(destination: PersonalInfo5View(types: illness)){
                        Capsule()
                            .foregroundColor(Color(red: 0.058823529411764705, green: 0.08235294117647059, blue: 0.16862745098039217))
                            .frame(height: 60)
                            .overlay(
                                Text("Next")
                                    .foregroundColor(.white)
                                    .font(.system(size: 20))
                                    .padding()
                            )
                    }
                }
            }
            .alert(isPresented: $showErrorMessage) { () -> Alert in
                Alert(title: Text("Alert"), message: Text("Please select at least 1 symptom"), primaryButton: .default(Text("Ok")), secondaryButton: .destructive(Text("Cancel")))
            }
            .padding()
        }
    }
}

struct TagsSelectionLayout: View {
    let illnesses: [Illness]
    @Binding var selectedSymptoms: Set<String>
    @EnvironmentObject var personalRecords: PersonalRecords

    var body: some View {
        List {
            ForEach(illnesses) { illness in
                ForEach(illness.symptoms, id: \.self) { symptom in
                    item(for: symptom)
                }
            }
        }
        .listStyle(PlainListStyle())
        .cornerRadius(5)
    }

    func item(for symptom: String) -> some View {
        Button(action: {
            if selectedSymptoms.contains(symptom) {
                personalRecords.selectedSymptoms.remove(symptom)
                selectedSymptoms.remove(symptom)
            } else {
                personalRecords.selectedSymptoms.insert(symptom)
                selectedSymptoms.insert(symptom)
            }
        }) {
            Text(symptom)
                .padding(.horizontal, 10)
                .padding(.vertical, 5)
                .font(.body)
                .foregroundColor(Color.black)
                
        }
        .listRowBackground(selectedSymptoms.contains(symptom) ? Color(red: 0.8901960784313725, green: 0.8705882352941177, blue: 1) : Color(red: 0.9725490196078431, green: 0.9725490196078431, blue: 0.9725490196078431))
        
    }
}

struct PersonalInfo4View_Previews: PreviewProvider {
    static var previews: some View {
        let personalRecords = PersonalRecords()
        let sampleIllness = Illness(name: "Sample Illness", desc: "Sample description", symptoms: ["Symptom 1", "Symptom 2"], types: ["Type 1"], preSick: false, bodyParts: ["Body Part"], feelings: ["Feeling"], treatments: ["Treatment"], prevention: ["Prevention"], img: "sample_image", relatedPharmacyRecords: [ PharmacyCategories(
            title: "Vicks VapoRub",
            menu: .vicks,
            desc: "icks VapoRub is a topical ointment applied to the chest and throat to provide relief from cough and congestion through its soothing vapors.",
            img: "fit"
        )], relatedHomemadeRecords: [HomemadeCategories(
            title: "Vicks VapoRub",
            menu: .peppermint,
            desc: "icks VapoRub is a topical ointment applied to the chest and throat to provide relief from cough and congestion through its soothing vapors.",
            img: "fit"
        )], relatedFitnessRecords: [
                FitnessCategories(
                    title: "Yoga",
                    menu: .yoga,
                    desc: "",
                    img: ""
                ),  FitnessCategories(
                    title: "Exercise",
                    menu: .exercise,
                    desc: "",
                    img: ""
                )
            ],relatedYogaRecords: [
                MainCategories(
                    title: "Child's Pose (Balasana)",
                    menu: .childsPoseHead,
                    desc: "A",
                    img: "migraine1"
                ),
                MainCategories(
                    title: "Downward",
                    menu: .corpsePose,
                    desc: "A",
                    img: "migraine2"
                ),
                MainCategories(
                    title: "Seated",
                    menu: .childsPoseHead,
                    desc: "A",
                    img: "migraine3"
                ),
                MainCategories(
                    title: "Alternate",
                    menu: .childsPoseHead,
                    desc: "A",
                    img: "migraine4"
                )
            ],relatedExerciseRecords: [
                MainCategories(
                    title: "Child's Pose (Balasana)",
                    menu: .childsPoseHead,
                    desc: "A",
                    img: "migraine1"
                ),
                MainCategories(
                    title: "Downward",
                    menu: .plank,
                    desc: "A",
                    img: "migraine2"
                ),
                MainCategories(
                    title: "Seated",
                    menu: .childsPoseHead,
                    desc: "A",
                    img: "migraine3"
                ),
                MainCategories(
                    title: "Alternate",
                    menu: .childsPoseHead,
                    desc: "A",
                    img: "migraine4"
                )
            ]
        )
        NavigationView {
           return PersonalInfo4View(illness: sampleIllness)
                .environmentObject(personalRecords)
        }
    }
}

