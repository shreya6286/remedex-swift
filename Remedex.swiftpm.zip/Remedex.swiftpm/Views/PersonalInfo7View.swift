//
//  PersonalInfo7View.swift
//  Remedex
//
//  Created by Shreya Bhavsar on 27/01/24.
//

import SwiftUI

struct PersonalInfo7View: View {
    let illness: Illness
    let customColor = Color(red: 0.9568627450980393, green: 0.9725490196078431, blue: 0.8431372549019608)
    var body: some View {
        ZStack {
            Color(red: 0.6784313725490196, green: 0.8470588235294118, blue: 1)
                .ignoresSafeArea()
            VStack {
                VStack {
                    HStack {
                        Circle()
                            .fill(Color(red: 0.8901960784313725, green: 0.8705882352941177, blue: 1))
                            .frame(width: 10, height: 10)
                        Circle()
                            .fill(Color(red: 0.8901960784313725, green: 0.8705882352941177, blue: 1))
                            .frame(width: 10, height: 10)
                        Circle()
                            .fill(Color(red: 0.4980392156862745, green: 0.3843137254901961, blue: 1))
                            .frame(width: 10, height: 10)
                        Circle()
                            .fill(Color(red: 0.8901960784313725, green: 0.8705882352941177, blue: 1))
                            .frame(width: 10, height: 10)
                    }
                    .padding()
                    .background(
                        RoundedRectangle(cornerRadius: 50)
                            .foregroundColor(.white)
                        )
                    HStack {
                        Text("Which other part of your body is bothering you?")
                            .font(.system(size: 23))
                            .bold()
                        Spacer()
                    }
                }
                .padding()
                .background(
                        RoundedRectangle(cornerRadius: 10)
                            .foregroundColor(customColor)
                        )
                VStack {
                    HStack {
                        Spacer()
                        BodyPartsMap()
                            .frame(width: 300, height: 400)
                        Spacer()
                    }
                }
                .padding()
                .background(
                    RoundedRectangle(cornerRadius: 10)
                        .foregroundColor(.white)
                    )
                Spacer()
                NavigationLink(destination: PersonalInfo8View(illness: illness)) {
                    Capsule()
                        .foregroundColor(Color(red: 0.058823529411764705, green: 0.08235294117647059, blue: 0.16862745098039217))
                        .frame(height: 60)
                        .overlay(
                            Text("Next")
                                .foregroundColor(.white)
                                .font(.system(size: 20))
                                .padding()
                        )
                }
                               }
            .padding()
        }
    }
}

struct BodyPartsMap: View {
    @State private var selectedParts: Set<BodyPart> = []
    var body: some View {
        GeometryReader { geometry in
            ZStack {
                Image("body")
                    .resizable()
                    .scaledToFit()

                ClickableArea (
                    shape: Circle(),
                    part: .head,
                    isSelected: selectedParts.contains(.head),
                    tapAction: {
                        toggleSelection(.head)
                    }
                )
                .frame(width: geometry.size.width * 0.1, height: geometry.size.height * 0.1)
                .position(x: geometry.size.width * 0.503, y: geometry.size.height * 0.06)
                
                ClickableArea (
                    shape: Circle(),
                    part: .rtarm,
                    isSelected: selectedParts.contains(.rtarm),
                    tapAction: {
                        toggleSelection(.rtarm)
                    }
                )
                .frame(width: geometry.size.width * 0.08, height: geometry.size.height * 0.08)
                .position(x: geometry.size.width * 0.325, y: geometry.size.height * 0.38)
                
                ClickableArea(
                    shape: Circle(),
                    part: .ltarm,
                    isSelected: selectedParts.contains(.ltarm),
                    tapAction: {
                        toggleSelection(.ltarm)
                    }
                )
                .frame(width: geometry.size.width * 0.08, height: geometry.size.height * 0.08)
                .position(x: geometry.size.width * 0.675, y: geometry.size.height * 0.38)
                
                ClickableArea(
                    shape: Circle(),
                    part: .chest,
                    isSelected: selectedParts.contains(.chest),
                    tapAction: {
                        toggleSelection(.chest)
                    }
                )
                .frame(width: geometry.size.width * 0.2, height: geometry.size.height * 0.1)
                .position(x: geometry.size.width * 0.5, y: geometry.size.height * 0.225)
                
                ClickableArea(
                    shape: Circle(),
                    part: .stomach,
                    isSelected: selectedParts.contains(.stomach),
                    tapAction: {
                        toggleSelection(.stomach)
                    }
                )
                .frame(width: geometry.size.width * 0.15, height: geometry.size.height * 0.1)
                .position(x: geometry.size.width * 0.5, y: geometry.size.height * 0.42)

                ClickableArea(
                    shape: Circle(),
                    part: .legs,
                    isSelected: selectedParts.contains(.legs),
                    tapAction: {
                        toggleSelection(.legs)
                    }
                )
                .frame(width: geometry.size.width * 0.08, height: geometry.size.height * 0.08)
                .position(x: geometry.size.width * 0.575, y: geometry.size.height * 0.6)
                
                ClickableArea(
                    shape: Circle(),
                    part: .knee,
                    isSelected: selectedParts.contains(.knee),
                    tapAction: {
                        toggleSelection(.knee)
                    }
                )
                .frame(width: geometry.size.width * 0.08, height: geometry.size.height * 0.08)
                .position(x: geometry.size.width * 0.45, y: geometry.size.height * 0.7)
                
                ClickableArea(
                    shape: Circle(),
                    part: .ankle,
                    isSelected: selectedParts.contains(.ankle),
                    tapAction: {
                        toggleSelection(.ankle)
                    }
                )
                .frame(width: geometry.size.width * 0.08, height: geometry.size.height * 0.08)
                .position(x: geometry.size.width * 0.5, y: geometry.size.height * 0.9)
                
                VStack {
                    ForEach(selectedParts.sorted(), id: \.self) { part in
                        Text(part.rawValue)
                            .foregroundColor(.black)
                            .padding(.all, 5)
                            .background(Color(red: 0.9137254901960784, green: 0.9098039215686274, blue: 0.9803921568627451))
                            .clipShape(RoundedRectangle(cornerRadius: 10))
                            .offset(x: -geometry.size.width * 0.4, y: -geometry.size.height * 0.05)
                    }
                }
            }
        }
    }

    func toggleSelection(_ part: BodyPart) {
        if selectedParts.contains(part) {
            selectedParts.remove(part)
        } else {
            selectedParts.insert(part)
        }
    }
}

struct ClickableArea<Content: Shape>: View {
    var shape: Content
    var part: BodyPart
    var isSelected: Bool
    var tapAction: () -> Void

    var body: some View {
        shape
            .foregroundColor(isSelected ? Color(red: 0.4980392156862745, green: 0.3843137254901961, blue: 1) : Color(red: 0.7647058823529411, green: 0.7490196078431373, blue: 1))
            .onTapGesture {
                tapAction()
            }
    }
}

enum BodyPart: String, Comparable, CaseIterable, Hashable {
    case head = "Head"
    case rtarm = "Right arm"
    case ltarm = "Left arm"
    case chest = "Chest"
    case stomach = "Stomach"
    case legs = "Legs"
    case knee = "Knee"
    case ankle = "Ankle"

    static func < (lhs: BodyPart, rhs: BodyPart) -> Bool {
        return lhs.rawValue < rhs.rawValue
    }
}


struct PersonalInfo7View_Previews: PreviewProvider {
    static var previews: some View {
        let personalRecords = PersonalRecords()
        let sampleIllness = Illness(name: "Sample Illness", desc: "Sample description", symptoms: ["Symptom 1", "Symptom 2"], types: ["Type 1"], preSick: false, bodyParts: ["Body Part"], feelings: ["Feeling"], treatments: ["Treatment"], prevention: ["Prevention"], img: "sample_image", relatedPharmacyRecords: [ PharmacyCategories(
            title: "Vicks VapoRub",
            menu: .vicks,
            desc: "icks VapoRub is a topical ointment applied to the chest and throat to provide relief from cough and congestion through its soothing vapors.",
            img: "fit"
        )], relatedHomemadeRecords: [HomemadeCategories(
            title: "Vicks VapoRub",
            menu: .peppermint,
            desc: "icks VapoRub is a topical ointment applied to the chest and throat to provide relief from cough and congestion through its soothing vapors.",
            img: "fit"
        )], relatedFitnessRecords: [
            FitnessCategories(
                title: "Yoga",
                menu: .yoga,
                desc: "",
                img: ""
                ), FitnessCategories(
                    title: "Exercise",
                    menu: .exercise,
                    desc: "",
                    img: ""
                )
            ],relatedYogaRecords: [
                MainCategories(
                    title: "Child's Pose (Balasana)",
                    menu: .childsPoseHead,
                    desc: "A",
                    img: "migraine1"
                ),
                MainCategories(
                    title: "Downward",
                    menu: .corpsePose,
                    desc: "A",
                    img: "migraine2"
                ),
                MainCategories(
                    title: "Seated",
                    menu: .childsPoseHead,
                    desc: "A",
                    img: "migraine3"
                ),
                MainCategories(
                    title: "Alternate",
                    menu: .childsPoseHead,
                    desc: "A",
                    img: "migraine4"
                )
            ],relatedExerciseRecords: [
                MainCategories(
                    title: "Child's Pose (Balasana)",
                    menu: .childsPoseHead,
                    desc: "A",
                    img: "migraine1"
                ),
                MainCategories(
                    title: "Downward",
                    menu: .plank,
                    desc: "A",
                    img: "migraine2"
                ),
                MainCategories(
                    title: "Seated",
                    menu: .childsPoseHead,
                    desc: "A",
                    img: "migraine3"
                ),
                MainCategories(
                    title: "Alternate",
                    menu: .childsPoseHead,
                    desc: "A",
                    img: "migraine4"
                )
            ]
        )

        NavigationView {
            return RecommendationsView(illness: sampleIllness)
                .environmentObject(personalRecords)
        }
    }
}
