//
//  HomemadeView.swift
//  Remedex
//
//  Created by Shreya Bhavsar on 27/01/24.
//

import SwiftUI

struct HomemadeView: View {
    @State public var selectedHomemade: HomemadeCategories?
    @State public var isActive: Bool = false
    var homeArray: [HomemadeCategories]
    init(homeArray: [HomemadeCategories]) {
            self.homeArray = homeArray
            UINavigationBar.appearance().backgroundColor = UIColor.red
        }
    var body: some View {
        ZStack {
            Color(.systemGray6)
            ScrollView {
                LazyVGrid(columns: [GridItem(.flexible(), spacing: 16), GridItem(.flexible(), spacing: 16)], spacing: 16) {
                    ForEach(homeArray) { item in
                        Button(action: {
                            selectedHomemade = item
                            isActive = true
                        }) {
                                HStack {
                                    Spacer()
                                    VStack(alignment: .leading) {
                                        HStack {
                                            Spacer()
                                            Image("\(item.img)")
                                                .resizable()
                                                .aspectRatio(contentMode: .fit)
                                                .frame(height: 100)
                                            Spacer()
                                        }
                                        Text("\(item.title)")
                                            .bold()
                                            .font(.system(size: 18))
                                            .padding(.bottom, -10)
                                            .foregroundColor(.black)
                                    }
                                    Spacer()
                                }
                                .padding()
                                .background(Color.white)
                                .cornerRadius(10)
                            }
                    }
                }
                .padding(16)
            }
            .background(
                NavigationLink("", destination: homemadeDestination(for: selectedHomemade), isActive: $isActive)
                    .hidden()
            )
        }
        .navigationBarColor(UIColor.systemGray6)
    }
    func homemadeDestination(for item: HomemadeCategories?) -> some View {
        if let item = item {
            switch item.menu {
            case .peppermint, .lavenderLemonade, .gingerMintTea, .eucalyptus, .gingerLemonade, .rosemary, .ketogenic, .goldenMilk, .spicyChickenSoup, .netiPot, .spinach, .blueberry, .salmon, .vitaminC, .aloeVera, .spicyBroth, .garlicHoney, .cabbage, .banana, .oat, .riceWater, .bratDiet, .bananaRice, .electrolyteSolution, .boiledPotatoes, .chamomile, .papayaHoneyBlend:
                return AnyView(CommonHomemadeView(selectedHomemade: item))
            }
        } else {
            return AnyView(EmptyView())
        }
    }

}

enum HomemadeMenu: String {
    case eucalyptus
    case lavenderLemonade
    case peppermint
    case rosemary
    case gingerMintTea
    case spicyChickenSoup
    case goldenMilk
    case netiPot
    case salmon
    case blueberry
    case spinach
    case vitaminC
    case aloeVera
    case gingerLemonade
    case garlicHoney
    case spicyBroth
    case cabbage
    case banana
    case oat
    case riceWater
    case bratDiet
    case bananaRice
    case electrolyteSolution
    case ketogenic
    case boiledPotatoes
    case papayaHoneyBlend
    case chamomile
}

struct CommonHomemadeView: View {
    var selectedHomemade: HomemadeCategories?
    @State var isActive: Bool = false
    init() {
            UINavigationBar.appearance().backgroundColor = UIColor.red
    }
    init(selectedHomemade: HomemadeCategories?) {
            self.selectedHomemade = selectedHomemade
    }
        var body: some View {
            ZStack {
                Color(.systemGray6)
                ScrollView {
                    VStack {
                        if let selectedHomemade = selectedHomemade {
                            VStack(alignment: .leading) {
                                HStack {
                                    Spacer()
                                    Image("\(selectedHomemade.img)")
                                        .resizable()
                                        .aspectRatio(contentMode: .fit)
                                        .padding()
                                        .frame(height: 300)
                                    Spacer()
                                }
                                .padding()
                                .background(Color.white)
                                .cornerRadius(10)
                                Text("\(selectedHomemade.title)")
                                    .bold()
                                    .font(.system(size: 30))
                                Text("\(selectedHomemade.desc)")
                                    .padding(.top, 3)
                            }
                        } else {
                            Text("No homemade selected")
                        }
                    }
                    .padding()
                }
            }
            .navigationBarColor(UIColor.systemGray6)
        }
}

