//
//  PersonalInfo2View.swift
//  Remedex
//
//  Created by Shreya Bhavsar on 27/01/24.
//

import SwiftUI

enum Gender: String, CaseIterable {
    case male = "Male"
    case female = "Female"
    case other = "Others"
}

struct PersonalInfo2View: View {
    @State var showErrorMessage = false
    @EnvironmentObject var personalRecords: PersonalRecords
    
    var body: some View {
        ZStack {
            VStack {
                VStack {
                    Image("heartLogo")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: 120)
                    HStack {
                        Text("Intake Interview")
                            .font(.system(size: 25))
                            .bold()
                        Spacer()
                        Text("2/2")
                            .font(.system(size: 20))
                            .bold()
                    }
                    ProgressView(value: 1)
                    HStack {
                        Text("Enter personal information")
                            .padding(.top, 10)
                            .padding(.bottom, 10)
                            .multilineTextAlignment(.leading)
                        Spacer()
                    }
                }
                .padding()
                .background(Color(red: 0.9568627450980393, green: 0.9725490196078431, blue: 0.8431372549019608)
                    .opacity(0.7)
                    .ignoresSafeArea())
                .clipShape(RoundedRectangle(cornerRadius: 15))
                Spacer()
                
                DatePicker(selection: $personalRecords.birthDate, displayedComponents: [.date]) {
                                Text("Select your birthdate")
                }
                .padding(.all, 10)
                .overlay(
                        RoundedRectangle(cornerRadius: 10)
                            .stroke(Color(red: 0.6784313725490196, green: 0.8470588235294118, blue: 1), lineWidth: 2)
                )
                .padding(.bottom, 5)
                
                TextField("Enter height in cm", text: $personalRecords.height)
                        .font(.system(size: 20))
                        .foregroundColor(.black)
                        .padding(.all, 13)
                        .overlay(
                            RoundedRectangle(cornerRadius: 10)
                                .stroke(Color(red: 0.6784313725490196, green: 0.8470588235294118, blue: 1), lineWidth: 2)
                        )
                        .padding(.bottom, 5)
                TextField("Enter weight in kg", text: $personalRecords.weight)
                        .font(.system(size: 20))
                        .foregroundColor(.black)
                        .padding(.all, 13)
                        .overlay(
                            RoundedRectangle(cornerRadius: 10)
                                .stroke(Color(red: 0.6784313725490196, green: 0.8470588235294118, blue: 1), lineWidth: 2)
                        )
                        .padding(.bottom, 10)
                VStack {
                    HStack {
                        Text("Select your gender:")
                            .font(.system(size: 15))
                            .padding(.leading, 5)
                        Spacer()
                    }
                    Picker("Gender", selection: $personalRecords.gender) {
                        ForEach(Gender.allCases, id: \.self) { gender in
                            Text(gender.rawValue)
                                .tag(gender.rawValue)
                        }
                    }
                    .pickerStyle(SegmentedPickerStyle())
                    .onAppear {
                        personalRecords.gender = Gender.male.rawValue
                    }
                }
                
                Spacer()
                if personalRecords.height == "" || !personalRecords.height.isValidHeightInCm || personalRecords.weight == "" || !personalRecords.weight.isValidWeightInKg {
                    Button(action: {
                        if self.personalRecords.height == "" || self.personalRecords.weight == "" {
                                self.showErrorMessage = true
                        }
                    }, label: {
                        Capsule()
                            .foregroundColor(Color(red: 0.058823529411764705, green: 0.08235294117647059, blue: 0.16862745098039217))
                            .frame(height: 60)
                            .overlay(
                                Text("Next")
                                    .foregroundColor(.white)
                                    .font(.system(size: 20))
                                    .padding()
                            )
                    })
                } else {
                    NavigationLink(destination: PersonalInfo3View()){
                        Capsule()
                            .foregroundColor(Color(red: 0.058823529411764705, green: 0.08235294117647059, blue: 0.16862745098039217))
                            .frame(height: 60)
                            .overlay(
                                Text("Next")
                                    .foregroundColor(.white)
                                    .font(.system(size: 20))
                                    .padding()
                            )
                    }
                }
            }
            .alert(isPresented: $showErrorMessage) { () -> Alert in
                Alert(title: Text("Alert"), message: Text("Please fill all the fields"), primaryButton: .default(Text("Ok")), secondaryButton: .destructive(Text("Cancel")))
            }
            .padding()
        }
    }
}

extension String {
    var isValidWeightInKg: Bool {
        NSPredicate(format: "SELF MATCHES %@", #"^\d{1,3}(\.\d{1,2})?$"#).evaluate(with: self)
    }
}

extension String {
    var isValidHeightInCm: Bool {
        NSPredicate(format: "SELF MATCHES %@", #"^\d{1,3}(\.\d)?$"#).evaluate(with: self)
    }
}

struct PersonalInfo2View_Previews: PreviewProvider {
    static var previews: some View {
        let personalRecords = PersonalRecords()
        return PersonalInfo2View()
            .environmentObject(personalRecords)
    }
}
