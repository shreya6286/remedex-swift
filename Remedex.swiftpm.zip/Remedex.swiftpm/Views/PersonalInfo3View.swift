//
//  PersonalInfo3View.swift
//  Remedex
//
//  Created by Shreya Bhavsar on 27/01/24.
//


import SwiftUI

struct PersonalInfo3View: View {
    @State private var searchTerm: String = ""
    let illnesses = DataManagerIllness.shared.illnesses
    @ObservedObject var dataManagerIllness = DataManagerIllness()
    var filteredIllnesses: [Illness] {
            if searchTerm.isEmpty {
                return dataManagerIllness.illnesses
            } else {
                return dataManagerIllness.illnesses.filter { $0.name.lowercased().contains(searchTerm.lowercased()) }
            }
        }
    
    var body: some View {
        ZStack {
            Color(.systemGray6)
            .ignoresSafeArea()
            VStack {
                Text("What symptoms are troubling you today?")
                    .padding(.bottom, 10)
                    .multilineTextAlignment(.leading)
                HStack {
                    TextField("Search", text: $searchTerm)
                        .padding(.horizontal)
                        .padding(.top, 8)
                        .padding(.bottom, 8)
                        .background(Color(.white))
                        .clipShape(RoundedRectangle(cornerRadius: 5))
                }
                List(filteredIllnesses) { illness in
                    NavigationLink(destination: PersonalInfo4View(illness: illness)) {
                        Text(illness.name)
                    }
                }
                .listStyle(InsetListStyle())
                .background(Color(.white))
                .clipShape(RoundedRectangle(cornerRadius: 5))
                Spacer()
            }
            .padding()
        }
    }
}

struct PersonalInfo3View_Previews: PreviewProvider {
    static var previews: some View {
        let personalRecords = PersonalRecords()
        return PersonalInfo3View()
            .environmentObject(personalRecords)
    }
}
