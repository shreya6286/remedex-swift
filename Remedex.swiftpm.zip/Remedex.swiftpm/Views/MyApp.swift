import SwiftUI

@main
struct MyApp: App {
    let personalRecords = PersonalRecords()
    var body: some Scene {
        WindowGroup {
            StartingContentView()
                .environmentObject(personalRecords)
        }
    }
}

