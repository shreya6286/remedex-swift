//
//  AnalyticsView.swift
//  Remedex
//
//  Created by Shreya Bhavsar on 02/02/24.
//

import SwiftUI

struct AnalyticsView: View {
    let illness: Illness
    @EnvironmentObject var personalRecords: PersonalRecords
    
    var body: some View {
        VStack {
            HStack {
                Spacer()
                Text("Medical Summary")
                    .font(.system(size: 30))
                    .bold()
                    .foregroundColor(.black)
                Image(systemName: "list.clipboard")
                    .font(.system(size: 30))
                    .foregroundColor(.black)
                Spacer()
            }
            VStack(spacing: 5){
                HStack {
                    Spacer()
                    Text("Personal Information")
                        .font(.system(size: 25))
                        .bold()
                        .foregroundColor(.black)
                        .padding(.bottom, 5)
                    Spacer()
                }
                HStack {
                    Text("\(personalRecords.firstName) \(personalRecords.lastName)")
                        .font(.system(size: 20))
                        .bold()
                        .foregroundColor(.black)
                    Spacer()
                }
                .padding(.bottom, 5)
                
                HStack {
                    Text("Email ID:")
                        .font(.system(size: 16))
                        .bold()
                        .foregroundColor(.black)
                    Text("\(personalRecords.email)")
                        .font(.system(size: 16))
                        .foregroundColor(.black)
                    Spacer()
                }
                
                HStack {
                    Text("Phone:")
                        .font(.system(size: 16))
                        .bold()
                        .foregroundColor(.black)
                    Text("\(personalRecords.phoneNumber)")
                        .font(.system(size: 16))
                        .foregroundColor(.black)
                    Spacer()
                }
                
                HStack {
                    Text("Height:")
                        .font(.system(size: 16))
                        .bold()
                        .foregroundColor(.black)
                    Text("\(personalRecords.height) cm")
                        .font(.system(size: 16))
                        .foregroundColor(.black)
                    Spacer()
                }
                
                HStack {
                    Text("Weight:")
                        .font(.system(size: 16))
                        .bold()
                        .foregroundColor(.black)
                    Text("\(personalRecords.weight) kg")
                        .font(.system(size: 16))
                        .foregroundColor(.black)
                    Spacer()
                }
                
                HStack {
                    Text("Gender:")
                        .font(.system(size: 16))
                        .bold()
                        .foregroundColor(.black)
                    Text("\(personalRecords.gender)")
                        .font(.system(size: 16))
                        .foregroundColor(.black)
                    Spacer()
                }
                
                HStack {
                    Text("BirthDate:")
                        .font(.system(size: 16))
                        .bold()
                        .foregroundColor(.black)
                    Text("\(formatDate(personalRecords.birthDate))")
                        .font(.system(size: 16))
                        .foregroundColor(.black)
                    Spacer()
                }
            }
            .padding()
            .background(
                RoundedRectangle(cornerRadius: 15)
                    .foregroundColor(Color(red: 0.9568627450980393, green: 0.9725490196078431, blue: 0.8431372549019608))
                    .opacity(0.7)
            )
            
            VStack(alignment: .leading, spacing: 20) {
                HStack {
                    Spacer()
                    Text("Illness Description")
                        .font(.system(size: 25))
                        .bold()
                        .foregroundColor(.black)
                    Spacer()
                }
                HStack {
                    Text("\(illness.name)")
                        .font(.system(size: 20))
                        .bold()
                        .foregroundColor(.black)
                    Spacer()
                }
                
                HStack {
                    VStack {
                        Text("Symptoms:")
                            .font(.system(size: 16))
                            .bold()
                            .foregroundColor(.black)
                            .padding(.top, -15)
                    }
                    Text("\(Array(personalRecords.selectedSymptoms).joined(separator: ", "))")
                        .font(.system(size: 16))
                        .foregroundColor(.black)
                }
                
                HStack {
                    Text("Types:")
                        .font(.system(size: 16))
                        .bold()
                        .foregroundColor(.black)
                        .padding(.top, -5)
                    Text("\(Array(personalRecords.selectedTypes).joined(separator: ", "))")
                        .font(.system(size: 16))
                        .foregroundColor(.black)
                }
                
                HStack {
                    Text("Previously ill:")
                        .font(.system(size: 16))
                        .bold()
                        .foregroundColor(.black)
                    Text("\(Array(personalRecords.selectedAnswer).joined(separator: ", "))")
                        .font(.system(size: 16))
                        .foregroundColor(.black)
                    Spacer()
                }
                
                HStack {
                    Text("Feelings:")
                        .font(.system(size: 16))
                        .bold()
                        .foregroundColor(.black)
                    ReactionMessageView()
                        .font(.system(size: 16))
                        .foregroundColor(.black)
                    Spacer()
                }
            }
            .padding()
            .background(
                RoundedRectangle(cornerRadius: 15)
                    .foregroundColor(Color(red: 1, green: 0.8705882352941177, blue: 0.9098039215686274))
                    .opacity(0.7)
            )
            Spacer()
        }
        .padding()
    }
    
    func formatDate(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "dd/MM/yyyy"
        return formatter.string(from: date)
    }
}

struct ReactionMessageView: View {
    @EnvironmentObject var personalRecords: PersonalRecords
    
    var body: some View {
        switch personalRecords.selectedFeelings {
        case "😃":
            return Text("Feeling great!")
        case "🙂":
            return Text("Feeling good.")
        case "😒":
            return Text("Feeling okay.")
        case "😔":
            return Text("Feeling not so good.")
        case "😢":
            return Text("Feeling sad.")
        default:
            return Text("Feeling okay.")
        }
    }
}



struct AnalyticsView_Previews: PreviewProvider {
    static var previews: some View {
        let personalRecords = PersonalRecords()
        let sampleIllness = Illness(name: "Sample Illness", desc: "Sample description", symptoms: ["Symptom 1", "Symptom 2"], types: ["Type 1"], preSick: false, bodyParts: ["Body Part"], feelings: ["Feeling"], treatments: ["Treatment"], prevention: ["Prevention"], img: "sample_image", relatedPharmacyRecords: [ PharmacyCategories(
            title: "Vicks VapoRub",
            menu: .vicks,
            desc: "icks VapoRub is a topical ointment applied to the chest and throat to provide relief from cough and congestion through its soothing vapors.",
            img: "fit"
        )], relatedHomemadeRecords: [HomemadeCategories(
            title: "Vicks VapoRub",
            menu: .peppermint,
            desc: "icks VapoRub is a topical ointment applied to the chest and throat to provide relief from cough and congestion through its soothing vapors.",
            img: "fit"
        )], relatedFitnessRecords: [
            FitnessCategories(
                title: "Yoga",
                menu: .yoga,
                desc: "",
                img: ""
                ), FitnessCategories(
                    title: "Exercise",
                    menu: .exercise,
                    desc: "",
                    img: ""
                )
            ],relatedYogaRecords: [
                MainCategories(
                    title: "Child's Pose (Balasana)",
                    menu: .childsPoseHead,
                    desc: "A",
                    img: "migraine1"
                ),
                MainCategories(
                    title: "Downward",
                    menu: .corpsePose,
                    desc: "A",
                    img: "migraine2"
                ),
                MainCategories(
                    title: "Seated",
                    menu: .childsPoseHead,
                    desc: "A",
                    img: "migraine3"
                ),
                MainCategories(
                    title: "Alternate",
                    menu: .childsPoseHead,
                    desc: "A",
                    img: "migraine4"
                )
            ],relatedExerciseRecords: [
                MainCategories(
                    title: "Child's Pose (Balasana)",
                    menu: .childsPoseHead,
                    desc: "A",
                    img: "migraine1"
                ),
                MainCategories(
                    title: "Downward",
                    menu: .plank,
                    desc: "A",
                    img: "migraine2"
                ),
                MainCategories(
                    title: "Seated",
                    menu: .childsPoseHead,
                    desc: "A",
                    img: "migraine3"
                ),
                MainCategories(
                    title: "Alternate",
                    menu: .childsPoseHead,
                    desc: "A",
                    img: "migraine4"
                )
            ]
        )

        NavigationView {
            return AnalyticsView(illness: sampleIllness)
                .environmentObject(personalRecords)
        }
    }
}

